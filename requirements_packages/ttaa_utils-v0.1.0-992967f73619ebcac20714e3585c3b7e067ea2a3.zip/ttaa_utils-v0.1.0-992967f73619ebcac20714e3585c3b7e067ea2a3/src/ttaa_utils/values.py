"""Collection of methods intended to work with values: ints, floats, etc. """


def ensure_int(value, default):
    """
    Converts the given value to int. If not possible, returns the default value

    >>> ensure_int(1, 0)
    1
    >>> ensure_int('1.0', 0)
    0
    >>> ensure_int('1.2', 0)
    0
    >>> ensure_int('a1.2', 0)
    0

    :param value: str : text to convert to int
    :param default: value to return if not possible to convert
    :return: int: user-default
    """
    try:
        value = int(value)
    except:
        return default
    return value

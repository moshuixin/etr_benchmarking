"""Tools made to work with dictionaries"""


class DicArrays:
    """
    Basic tools to work with array of dictioanries
    """
    def __init__(self, dics=(), **kwargs):
        self.dics = dics

    def list_key_values(self, key):
        """ Returns a list that contains value=dict[key] for each dictionary
        in the array. In other words, it groups by key. It assumes that the
        dictionary has the same/equivalent type of elements under the given
        key.

        :param key: str : string for a dictioanary key
        :return: list
        """
        keys = []
        for dic_ in self.dics:
            if key in dic_.keys():
                keys.append(dic_[key])
        return keys

    def sum_by_key(self, key):
        """Sums all the values under the given key from all the dictionaries
        in the array. It assumes that the dictionary has the same/equivalent
        type of elements and they can be sumed.

        :param key: str : key within the dictionary
        :return: int/double/whatever is in the key.

        """
        _sum = 0
        for dic_ in self.dics:
            if key in dic_.keys():
                _sum += dic_[key]
        return _sum

    def get_paired_keys(self, key1, key2):
        """ Returns an array of tuples consisting of (dict[key1], dict[key2]).
        Both keys must exist in all dictionaries at the same time.

        :param key1: str: dictionary key
        :param key2: str: dictionary key
        :return: list

        """
        pairs = []
        for dic_ in self.dics:
            if key1 not in dic_.keys():
                continue
            if key2 not in dic_.keys():
                continue
            pairs.append((dic_[key1], dic_[key2]))
        return pairs

    def list_grouped_by_key_values(self, key1, key2):
        """
        groups in key[]a list with the key dic[key1] all the values of
        dic[key2]

        :param key1: str: dictionary key to group in
        :param key2: str: dictionary key to group by
        :return: dictionary

            >>> test = [
                {'id':1, 'status':0, 'desc': 'desc 1'},
                {'id':2, 'status':1, 'desc': 'desc 2'},
                {'id':3, 'status':2, 'desc': 'desc 3'},
                {'id':4, 'status':0, 'desc': 'desc 4'},
                {'id':5, 'status':4, 'desc': 'desc 5'},
                {'id':6, 'status':5, 'desc': 'desc 6'},
            ]
            >>> p = DicArrays(test)
            >>> p.list_key_values('status', 'id')
            {0: [1, 4], 1: [2], 2: [3], 4: [5], 5: [6]}
        """

        mapped = {}
        for dic_ in self.dics:
            if key1 not in dic_.keys():
                # if the searched key is not in the dictionary, nothing can
                # be done... RIP
                continue
            # te key in the mapped dict should be the value from key1
            key_entry = dic_[key1]

            if key_entry not in mapped.keys():
                mapped[key_entry] = []
            mapped[key_entry].append(dic_[key2])
        return mapped

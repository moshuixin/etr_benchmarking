""" Collection of wrappers to be used with encrypted information. It uses
Symmetric encryption: https://en.wikipedia.org/wiki/Symmetric-key_algorithm

It wraps around the package: https://cryptography.io/
"""

import uuid
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


def get_kdf(salt):
    """'Password-Based Key Derivation Function 2'.
    It used for deriving a cryptographic key from a password.
    Please read what PBKDF2, this class is just a wrapper.

    :param salt: bites: Secure values (16 bytes) or longer and randomly
      generated.
    :return: PBKDF2HMAC instance

    """
    return PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )


def get_fernet(secret_key, salt):
    """ Returns a Fernet for the given key using the given salt

    :param secret_key: key use to encrypt and decrypt messages.
    :param salt: UUID, 'see new_salt()'
    :return: Fernet instance

    """

    kdf = get_kdf(salt)
    key = base64.urlsafe_b64encode(kdf.derive(secret_key.encode()))
    return Fernet(key)


def new_salt():
    """Wrapper for 'uuid.uuid4()' which generates a random UUID. By default
    it uses 16 bits. If you need bites, do not forget to convert it.

    :return: str: uuid

    """
    return uuid.uuid4().hex


if __name__ == "__main__":

    print("Salt: Random generated salt: 16 bits")
    print("\t", new_salt())

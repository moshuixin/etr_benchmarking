from enum import Enum


class ExtendedEnum(Enum):

    def __str__(self):
        """
        >>> class MyExtendedEnum(ExtendedEnum):
        ...     FOO1 = 'BAR 1'
        >>> str(MyExtendedEnum.FOO1)
        'BAR 1'

        """
        return str(self.value)

    @classmethod
    def tuple(cls):
        """
        Returns a tuple formed by all the values defined inside the class

        :return: tuple

        >>> class MyExtendedEnum(ExtendedEnum):
        ...     FOO1 = 'BAR 1'
        ...     FOO2 = 'BAR 2'
        >>> MyExtendedEnum.tuple()
        ('BAR 1', 'BAR 2')
        """

        return tuple(map(lambda x: x.value, list(cls)))


class LabeledEnum(Enum):
    """
    Extended enumeration class: implements some methods to work with tuples
    formed by a key and a label in the format:
    FOO = (int, foo).

    This class was thought to work with Pairs required by Django models and
    define a simple method to generate them and
    compare them.

    >>> class MyLabeledEnum(LabeledEnum):
    ...     FOO1 = (1, 'BAR 1')
    ...     FOO2 = (2, 'BAR 2')
    ...     FOO3 = (3, 'BAR 3')

    >>> MyLabeledEnum.FOO1 is MyLabeledEnum.FOO1
    True
    >>> MyLabeledEnum.FOO1 == MyLabeledEnum.FOO1
    True
    >>> MyLabeledEnum.FOO1 is not MyLabeledEnum.FOO2
    True
    >>> MyLabeledEnum.FOO1 == MyLabeledEnum.FOO2
    False
    >>> MyLabeledEnum.FOO1.key
    1
    >>> MyLabeledEnum.FOO1.label
    'BAR 1'

    """

    def __init__(self, key, label):
        """
        This init method is called when an
        attribute for the class is defined; therefore, the main class does
        not require to define key and label manually. This is because each
        Attribute defined in the class calls this init with the  parameters
        defined in the tuple. Therefore, each defined attribute is also a
        class.

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')

        >>> MyLabeledEnum.FOO1.key
        1
        >>> MyLabeledEnum.FOO1.label
        'BAR 1'

        :param key:
        :param label:
        """
        self.key = key
        self.label = label

    def get_pair(self):
        """Returns a tuple consisting of (key, label) for the given value

        :return: tuple

        """
        return self.key, self.label

    def __str__(self):
        """ String representation of the given enumeration. By default it
        returns the string conversion of the key associated to a value

        :return: str


        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        >>> str(MyLabeledEnum.FOO1)
        '1'


        """
        return str(self.key)

    def __unicode__(self):
        """String (utf-8) representation of the given enumeration. By
        default it returns the string conversion of the key associated to a
        value

        :return: str utf-8

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        >>> str(MyLabeledEnum.FOO1)
        '1'

        """
        return str(self.key, 'utf-8')

    @classmethod
    def from_key(cls, key):
        """ Returns the complete definition of the given key or None if not
        found

        :param key: different values: key to search for
        :return: different types, label associated to the given key

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.from_key(1)
        <MyLabeledEnum.FOO1: (1, 'BAR 1')>
        >>> MyLabeledEnum.from_key(-1) == None
        True

        """
        return next(iter(filter(lambda x: x.key == key, list(cls))), None)

    @classmethod
    def tuples(cls):
        """ Returns a tuple formed by pairs (key, label) for all the elements
        inside the class

        :return: tuple of 2-elements-tuples

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.tuples()
        ((1, 'BAR 1'), (2, 'BAR 2'), (3, 'BAR 3'))

        """

        return tuple(map(lambda x: x.value, list(cls)))

    @classmethod
    def keys(cls):
        """ Returns a tuple containing just the keys of all the elements inside
        the class as elements.
        :return: tuple of different types

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.keys()
        (1, 2, 3)
        """
        return tuple(map(lambda x: x.key, list(cls)))

    @classmethod
    def labels(cls):
        """Returns a tuple containing just the labels of all the elements
        inside the class as elements.
        :return: tuple of different types

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.labels()
        ('BAR 1', 'BAR 2', 'BAR 3')
        """
        return tuple(map(lambda x: x.label, list(cls)))

    @classmethod
    def describe(cls):
        """
        Prints in the console a table a horrible table showing the key and
        their corresponding values of all the definitions inside the class

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.describe()
        Class:  MyLabeledEnum
        Key | Label
        ----------
          1 | BAR 1
          2 | BAR 2
          3 | BAR 3

        """

        keylist = list(map(str, cls.keys())) + ["Key"]

        max_ = max(list(map(len, keylist)))
        if max_ < 2:
            max_ = 2
        row_format = "{:>" + str(max_) + "}" + " | {:}"
        headers = ["Key", "Label"]
        print("Class: ", cls.__name__)
        headerline = row_format.format(*headers)
        print(headerline)
        print("-"*(len(headerline)-1))

        for item in cls:
            print(row_format.format(str(item.key), item.label))

    @classmethod
    def get_element_by_key(cls, key):

        """
        return the complete element that has the given key

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.get_element_by_key(1)
        <MyLabeledEnum.FOO1: (1, 'BAR 1')>
        """

        for item in cls:
            if item.key == key:
                return item
        return None

    @classmethod
    def get_element_key_by_label(cls, label):
        """
        return the complete element that has the given key

        >>> class MyLabeledEnum(LabeledEnum):
        ...     FOO1 = (1, 'BAR 1')
        ...     FOO2 = (2, 'BAR 2')
        ...     FOO3 = (3, 'BAR 3')
        >>> MyLabeledEnum.get_element_key_by_label('BAR 1')
        1

        """

        for item in cls:
            if item.label == label:
                return item.key
        return None

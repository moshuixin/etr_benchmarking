"""Introduces some commonly used values as ready to use definitions"""


class DbDefaults:
    """Basic definitions to use with databases"""
    
    BLANK = ''
    NULL = None
    ZERO = 0

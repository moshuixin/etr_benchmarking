from . constants import ExtendedEnum, LabeledEnum
from . import value_definitions
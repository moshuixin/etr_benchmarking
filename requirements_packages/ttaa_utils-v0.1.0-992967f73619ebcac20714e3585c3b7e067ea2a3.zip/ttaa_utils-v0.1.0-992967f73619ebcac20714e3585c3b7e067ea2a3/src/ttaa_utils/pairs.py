"""Tools intended to work with pair of arrays and consider them as ordered
pairs (coordinates)

More classes and methods might come...
"""


class PairsManager:
    """Intended to work on different iterable of data and treat them as
    ordered pairs. It behaves as a pseudo dictionary class where the keys
    and values can be given as lists. It does not checks data types, just if
    they are or can be paired or not.

    :param pairs: list: list of sorted pairs
    :param col_x: list: list of values with length n
    :param col_y: list: list of values with length n (it has to match
      length of colX)
    """

    def __init__(self, pairs=(), col_x=(), col_y=(), **kwargs):

        self.col_x = col_x
        self.col_y = col_y
        self.pairs = pairs
        if not pairs:
            self.pairs = self.make_pairs()
        self.keys = self._get_keys()
        self.values = self._get_values()

    def make_pairs(self):
        """
        Generates a list of ordered pairs from the given columns or using the
        default self.colX and self.colY if nothing is given

        :return: list: list of ordered pairs

        """

        if self.pairs:
            return self.pairs
        if len(self.col_x) == len(self.col_y):
            return list(zip(self.col_x, self.col_y))
        return []

    def _get_keys(self):
        """
        In a first attempt generates a list with all the x values o the pairs
        in self.pairs. If no pairs were given, it checks if the given
        xy columns have the same lengths and if yes, returns the x column.

        :return: list: of values

        """
        pairs = self.pairs
        if not pairs and len(self.col_x) == len(self.col_y):
            return self.col_x
        keys = []
        for pair in pairs:
            keys.append(pair[0])
        return keys

    def _get_values(self):
        """
        In a first attempt generates a list with all the y values o the pairs
        in self.pairs. If no pairs were given, it checks if the given xy
        columns have the same lengths and if yes, returns the y column.

        :return: list: of values

        """
        pairs = self.pairs
        if not pairs and len(self.col_x) == len(self.col_y):
            return self.col_y
        keys = []
        for pair in pairs:
            keys.append(pair[1])
        return keys

    def search_by_key(self, key):
        """
        Search in the X column the first occurrence of the given x value and
        returns its corresponding y value.

        :param key: different types: key to search for in the X column
        :return: different types or None: first occurrence of the corresponding
          y to X

        """
        pairs = self.pairs
        if not pairs:
            pairs = self.make_pairs()

        for pair in pairs:
            if len(pair) < 2:  # Just in case self.pairs is used and badly set
                continue
            if pair[0] == key:
                return pair[1]
        return None

    def search_by_value(self, value):
        """
        Search in the Y column the first occurrence of the given y value and
        returns its corresponding x value.

        :param value: different types: key to search for in the x column
        :return: different types or None: first occurrence of the corresponding
          y to X

        """
        pairs = self.pairs
        if not pairs:
            pairs = self.make_pairs()

        for pair in pairs:
            if len(pair) < 2:  # Just in case self.pairs is used and badly set
                continue
            if pair[1] == value:
                return pair[0]
        return None

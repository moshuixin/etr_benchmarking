"""Definition of general purpose exceptions to be used with different
applications. Each error can be imported and used directly in order to
define and rise specific errors.

"""


class ProcessingException(Exception):
    """General purpose exception intended to be triggered by error in
    general processes.
    """
    def __init__(self, *args, **kwargs):
        super(ProcessingException, self).__init__(*args, **kwargs)


class StorageException(Exception):
    """General purpose exception intended to be triggered by error while
    storing something.
    """
    def __init__(self, *args, **kwargs):
        super(StorageException, self).__init__(*args, **kwargs)


class DbStorageException(StorageException):
    """General purpose exception intended to be triggered by error in
    storing to the DB.
    """
    def __init__(self, *args, **kwargs):
        super(DbStorageException, self).__init__(*args, **kwargs)


class DiskStorageException(StorageException):
    """General purpose exception intended to be triggered by error in
    storing to a file.
    """
    def __init__(self, *args, **kwargs):
        super(DiskStorageException, self).__init__(*args, **kwargs)

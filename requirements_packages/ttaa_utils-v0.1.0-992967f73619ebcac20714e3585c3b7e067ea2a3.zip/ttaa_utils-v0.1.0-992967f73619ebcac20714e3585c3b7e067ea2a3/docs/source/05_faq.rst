==========================
Frequently Asked Questions
==========================

* Which problems did other people encounter while installing or using your app? 
* What was the solution for those problems?

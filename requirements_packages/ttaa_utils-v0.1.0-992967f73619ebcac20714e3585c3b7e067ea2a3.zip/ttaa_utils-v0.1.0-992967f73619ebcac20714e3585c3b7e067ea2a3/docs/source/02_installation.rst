============
Installation
============

For usage
---------
In order to install this package in your pc, clone the repo in a permanent location (where you will install it) or download a ready to use release and keep reading.

This is an example for the possible setup of a library located by default within the src/ folder.
All packages will be installed to python.site-packages

For a installation of the current version (or whatever you downloaded) without git connection, use:

    >>> python setup.py install


For development
---------------
If you want to install the package and keep connection to 'git' and the repository (recomended if you want to get updates and contribute to the package) use:

    >>> python setup.py develop --user

See `here <https://stackoverflow.com/questions/19048732/python-setup-py-develop-vs-install>`_ for a detailed discussion on the differences between install and develop. If unsure, use install. The test_suite located within the test/ folder will be executed automatically.

Git Integration
^^^^^^^^^^^^^^^

This section assumes that you installed the package by cloning the repository. Therefore, the installation folder will be your repository as well.
In function of the branch you use, just update the git repository.

*  By development, it assumes you are using the dev branch as default and is the branch you want to pull into. If you use another branch, change the name.

    >>> git pull origin dev

If you use the package based on releases, you need to get the new version of the origin and then checkout to that release.

    >>> git fetch origin
    >>> git checkout <release label>
    
Please note that <release label> is the label you want to change to.

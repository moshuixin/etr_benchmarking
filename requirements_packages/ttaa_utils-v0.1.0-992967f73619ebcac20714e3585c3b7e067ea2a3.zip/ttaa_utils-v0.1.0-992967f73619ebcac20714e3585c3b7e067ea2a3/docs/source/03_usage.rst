==========
User Guide
==========

Just import as you would do with numpy

    >>> from ttaa_utils.<module>.<submodule>...


Examples
--------

    >>> from ttaa_utils.constants import ExtendedEnum
    >>> 
    >>> 
    >>> class CoolEnumeration(ExtendedEnum):
    >>>     """
    >>>     Enumeration of the possible source countries
    >>>     """
    >>>     A = 'a'
    >>>     B = 1
    >>>     C = 3
    >>>     D = 'blabla'
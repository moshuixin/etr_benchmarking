======
Crypto
======

This module provides a serie of method intended to be shorcuts for the packages 'uuid' and 'cryptography'.


The module
----------
.. automodule:: ttaa_utils.crypto
    :members:


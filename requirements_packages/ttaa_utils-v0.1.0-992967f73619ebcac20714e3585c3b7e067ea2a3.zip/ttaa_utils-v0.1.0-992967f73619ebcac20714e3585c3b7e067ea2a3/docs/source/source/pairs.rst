=====
Pairs
=====

Set of tools work with iterables that are in principle not related. It provides methods to treat those iterables as coordinates (x,y) and to search by any them.


The module
----------
.. automodule:: ttaa_utils.pairs
    :members:


============
Dictionaries
============

This module provides a serie of method and classes to work with dictionaries and list of dictionaries


The module
----------
.. automodule:: ttaa_utils.dictionaries
    :members:


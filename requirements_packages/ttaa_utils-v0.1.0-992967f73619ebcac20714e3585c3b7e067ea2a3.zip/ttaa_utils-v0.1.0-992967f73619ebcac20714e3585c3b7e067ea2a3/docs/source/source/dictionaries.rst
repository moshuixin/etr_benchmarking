==========
Exceptions
==========

Set of "ready" to use exceptions in python code.


The module
----------
.. automodule:: ttaa_utils.exceptions
    :members:


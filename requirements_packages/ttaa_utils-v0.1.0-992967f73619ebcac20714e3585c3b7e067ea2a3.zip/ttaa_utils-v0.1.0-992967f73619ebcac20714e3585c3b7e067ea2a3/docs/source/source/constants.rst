=========
Constants
=========

This module provides a serie of classes based on 'Enum' that allow the definition of new enumerations with labels while keeping all the default behaviour of Enum.


How to use
----------
Just import and extednd the classes:


    >>> from ttaa_utils.constants import ExtendedEnum
    >>> class MyExtendedEnum(ExtendedEnum):
    ..      FOO1 = 'BAR 1'
    ..      FOO2 = 'BAR 2'
    >>> MyExtendedEnum.FOO1 == MyExtendedEnum.FOO1
    True
    >>> MyExtendedEnum.FOO1 is MyExtendedEnum.FOO1
    True
    >>> MyExtendedEnum.FOO1 == MyExtendedEnum.FOO2
    False
    >>> MyExtendedEnum.FOO1 is MyExtendedEnum.FOO2
    False
    >>> MyExtendedEnum.FOO1 is not MyExtendedEnum.FOO2
    True
    >>> str(MyExtendedEnum.FOO1)
    'BAR 1'

The module
----------

.. automodule:: ttaa_utils.constants.constants
    :members:


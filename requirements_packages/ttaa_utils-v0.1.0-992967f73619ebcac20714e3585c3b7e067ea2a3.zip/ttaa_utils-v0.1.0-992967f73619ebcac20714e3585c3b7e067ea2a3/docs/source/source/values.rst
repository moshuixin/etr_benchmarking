======
Values
======

Set of tools to work with numerical values and ensure certain properties.


The module
----------
.. automodule:: ttaa_utils.values
    :members:


=====
About
=====

Description
-----------

Basic package from the EY - TTAA team in Stuttgart used to provide basic tools to work with enumeration, cryptographic data, numerical values and dictionaries.

This package becomes handy when working with simple and repetitive tasks such as transforming any input into an int (see values.ensure_int) or when defining constants that you use all over your code.

Soon or later, every program has to define some constants to check values, inputs or outputs. That can be done with this package while using the enumeration class (see constants.ExtendedEnum). If that constant requires a name to be seen by the user, the class LabeledEnum ( see constants.LabeledEnum) can be used instead.

Example:

  Let say you need to define some constants to define formats that you use in your app, let say PDFs and TXTs. You could check everywhere against 'pdf' or 'txt' like this:

   >>> if format_type == 'txt':
   >>>     ..  do_something()

That is not good, it is hardcoded. What would make sense is to check against a constat defined somewhere called TXT with the value ```TXT = 'txt' ```. Then, you do not write the value of the constant anymore, but the representation of that variable. Now, the problem is grouping, how to store those definitions in a way that make sense? Different files where each one talks for one definition? This is not ok, if you have a lot of types of enumerations, soon or later it will be difficult to maintain: if you have 50 types of definitions, I don’t think you want to have 50 files. In that case, one can use ExtendedEnum.

 >>> class Formats(ExtendedEnum):
    ..      TXT = 'txt'
    ..      PDF = 'pdf'

Then, you could have all your definitions in a single file, every single one of them in a consistent grouping. If you want to compare afterwards you simple call the definitions. For detailed information of how to compare, read the information of the Enum class: `https://docs.python.org/3/library/enum.html <https://docs.python.org/3/library/enum.html>`_

    >>> Formats.TXT == Formats.TXT
    True
    >>> Formats.TXT is Formats.TXT
    True
    >>> Formats.TXT == 'txt'
    False
    >>> Formats.TXT.value == 'txt'
    True

For further information, read the documentation of the class.

Now, if you need to add names to each element in that enumeration, you might want to define labels to them. However, the idea of defining another class that holds the labels pointing to this one is not the optimum and gets crazy very fast. Therefore, we use the LabeledEnum. With this class we can define constants and assign them a name or label. It can be seen as a machine friendly version and a user friendly version.

Example:

    >>> class LabeledFormats(LabeledEnum):
    ...     TXT = ('txt', 'Plain text')
    ...     PDF = ('pdf', 'Portable document file')

In this case, each format has a key (int) and is represented by a string (label), therefore the pair is (key, label). And we can use:

    >>> LabeledFormats.TXT == LabeledFormats.TXT
    True
    >>> LabeledFormats.TXT == LabeledFormats.TXT
    True
    >>> LabeledFormats.TXT is LabeledFormats.PDF
    False
    >>> LabeledFormats.TXT == 'txt'
    False
    >>> LabeledFormats.TXT.label == 'Plain text'
    True
    >>> LabeledFormats.TXT.key == 'txt'
    True

For further information, read the documentation of the class.

What about using this definitions in a form in a web page. If you use django, you require a list of tuples with the value that you assign to the html-label 'value' (we call that key) and what the user actually can see (we called that label).
Lets assume you use Django, to use that list in a dropdown, Django will ask for a list of tuples with the structure '(value, label)' for each element. Whit this claws, you just use the method tuples() of the enumeration, which gives you a list of tuples with that exact structure:

    >>> LabeledFormats.tuples()
    (('txt', 'Plain text'), ('pdf', 'Portable document file'))

Now, in django, you just need to use

    >>> choices = LabeledFormats.tuples()

And you will have all the pairs in a ready-to-use format.

There are more methods defined: if you want to search an element with the key (or label), getting just keys, or getting just labeled. Just read the documentation!


* Repository: `http://10.101.92.51/ttaa_framework/ttaa_utils <http://10.101.92.51/ttaa_framework/ttaa_utils>`_

Further reading
---------------

* `https://docs.python.org/3/library/enum.html <https://docs.python.org/3/library/enum.html>`_


Requirements
------------

* enum
* uuid
* base64
* cryptography


:Author:
    Cristian González Mora

:Version: 0.1.0 of 2017/10/10

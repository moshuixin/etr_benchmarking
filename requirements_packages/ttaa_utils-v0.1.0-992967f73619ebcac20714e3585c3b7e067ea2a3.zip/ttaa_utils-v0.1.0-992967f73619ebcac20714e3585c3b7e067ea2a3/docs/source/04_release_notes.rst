=============
Release notes
=============

* 0.1.0 - 2017.10.10
     First release. it includes tools to work with constants, dictionaries and common encryption. For further information see:
       * crypto: for common cryptographic tools
       * dictionaries: to work with array of dictionaries
       * exceptions: for premade exceptions that can be used out of the box
       * pairs: for methods to work with pairs of data as x,y coordinates.
       * values: simple methods to work with different types of values such as ints
       * constants: some methods and classes to work with... wait for it... constants!
           * constants: for methods to define constants that can be sued in django or any other types of tools
           * value_definitions: for some definitions of constants to be used in different contexts.

# TTAA - Utils

## Description
Basic package from the EY - TTAA team in Stuttgart used to provide basic tools to work with enumeration, cryptographic data, numerical values and dictionaries.

## Requirements

* enum
* uuid
* base64
* cryptography

## Installation

In order to install this package in your pc, clone the repo in a permanent location (which means never move it) or download a ready to use release package. There are two possibilities in terms of installation. One one hand, you can download a certain release and install it (system package), or you can install it as developer version by cloning the git repository. You decide.


### System package

This is the recommended installation if you are using the package for official releases of your apps. In this case, you should install a stable release and updated from stable to stable when needed.

This is an example for the possible setup of a library located by default within the src/ folder.
All packages will be installed to python.site-packages

For a installation of the current version (or whatever you downloaded) without git connection, use:

    >>> python setup.py install

Now the package is ready to use

### Development (recommended)

This is the version you need if you want to contribute to the project in any way or want to use the bleeding edge version (latest features, it also means latest bugs). This option will hold a version in the git which is why you will be able to get updates without reinstalling. Another advantage of this version is that will enable to change from one stable version to another by using git and checking out to another tag/branch.

    >>> python setup.py develop

#### User based
If you want to install the development version just for your user (no other accounts), you can use:

    >>> python setup.py develop --user

Which means, other users will not see the package installed on your system.

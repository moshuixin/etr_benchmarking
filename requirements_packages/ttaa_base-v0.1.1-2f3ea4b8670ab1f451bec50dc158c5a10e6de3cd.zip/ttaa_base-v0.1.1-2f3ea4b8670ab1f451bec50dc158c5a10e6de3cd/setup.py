#!/usr/bin/env python
"""
This is an example for the possible setup of a library
located by default within the src/ folder.
All packages will be installed to python.site-packages
simply run:

    >>> python setup.py install

For a local installation or if you like to develop further

    >>> python setup.py develop --user


The test_suite located within the test/ folder
will be executed automatically.
"""
import codecs
from setuptools import setup, find_packages

source_path = 'src'
packages = find_packages(source_path)
__version__ = '0.1.1'

def read_files(*filenames):
    """
    Output the contents of one or more files to a single concatenated string.
    """
    output = []
    for filename in filenames:
        f = codecs.open(filename, encoding='utf-8')
        try:
            output.append(f.read())
        finally:
            f.close()
    return '\n\n'.join(output)

# Define your setup
# version should be considered using git's short or better the full hash
def get_version_from_git():
    """
    Get the short version string of a git repository
    :return: (str) version information
    """
    import subprocess
    try:
        _v = subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD'])
        v = _v.decode('utf-8').strip()
        version = __version__ + '-' +v
        return version
    except Exception as ex:

        print("Could not retrieve git version information")
    return __version__  # default


setup(
    name='ttaa_base',
    version=__version__,
    description='Provides a set of middleware, templates and functionalities '
                'to use with web apps developed by the EY-TTAA team in '
                'Stuttgart.',
    long_description=read_files('README.md', 'CHANGES.rst'),
    author='Stefan Otte, Cristian Gonzalez',
    author_email='stefan.otte@de.ey.com',
    url='',
    packages=packages,
    install_requires=['django(>=1.11.5,<1.12)', 'ttaa_utils'],
    package_dir={'': source_path},
    zip_safe=False,
    include_package_data=True,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.6',
        'Framework :: Django',
    ],
)

==========
User Guide
==========

Tutorial
--------

The following tutorial describes how to set up a new and empty project that uses ttaa_base. If you have an existing projects and 
want to include this package, adapt the following descriptions and commands as needed.

**Download the packages**

Download the most recent versions of the following required packages by cloning the appropriate git repositories:

* `ttaa_utils <http://10.101.92.51/ttaa_framework/ttaa_utils>`_
* `ttaa_base <http://10.101.92.51/ttaa_framework/ttaa_base>`_

.. Note::
  The dependency on ttaa_django_logger was removed since the feature was made part of ttaa_base. The configuration remains similar and it is now included in this tutorial.



**Learn git and django**

1. Always use git.
2. Learn the basics of django by following a tutorial of your choice. Recommendations are 

    * `Official Django Tutorial <https://docs.djangoproject.com/en/1.11/intro/tutorial01/>`_
    * `Django Girls <https://tutorial.djangogirls.org/en/>`_
    * `The New Boston (Youtube Videos) <https://www.youtube.com/watch?v=qgGIqRFvFFk&list=PL6gx4Cwl9DGBlmzzFcLgDhKTTfNLfX1IK>`_

**Create a project folder**

Make a project folder somewhere and switch to it! Know that your software project will contain more than just your django project. For example, your documentation. 

**Setup your virtual environment**

In order to prevent compatibility issues further down the road, you
should set up a virtual environment with the required python 
packages specifically for your project. For example, to set up and activate an environment in the current folder called "env",
run the following commands in the same directory as this file to setup
the virtual environment (will be stored in env/):

.. code-block:: none

   python -m venv env
   .\env\Scripts\activate

(The commands are Linux friendly, but also tested on Windows 7. Adapt them depending on your operating system.)

**Install the packages - Order matters!**


1. Install ttaa_utils by using ``python setup.py install`` in the folder where the ``setup.py`` resides. Open setup.py for more detailed information. Then, follow the instructions provided with that package.
2. Install django by using ``pip install django<1.12``. Remember, ttaa_base is just compatible with Django 1.11.5 onwards. If you need another version of django (and you should have a damn good reason for that, since 1.11 has long term support and is TTAA team standard!), adapt that command accordingly. 
3. Install ttaa_base the same way you installed ttaa_utils

You also have the option of installing "developer versions" of the packages by running ``python setup.py develop`` instead. This is recommend if you want to play with the code or want to contribute to the project, but do not do that if you just want to use the packages. See `Stackoverflow <https://stackoverflow.com/questions/19048732/python-setup-py-develop-vs-install>`_ for a detailed discussion on the differences. If unsure, use install.

**Start a fresh django project**

1. Start the project by using ``django-admin startproject mysite``. Substitute mysite with the name of your project.
2. Initialize the git repository by using ``git init``. 
3. Add your .gitignore. If you don't know what that is, you did not learn `git <https://git-scm.com/>`_. 
4. Change into the django project directory by using ``cd mysite``
5. Start a new django app by using ``python manage.py startapp test_app``. Substitute test_app with the name of your application. If you don't know the difference between a django app and a django project, you did not learn `django <https://docs.djangoproject.com/en/1.11/intro/tutorial01/>`_.

Note: The default configuration of django uses an SQLite database, but you are of course free to use any supported database. Click `here <https://docs.djangoproject.com/en/1.11/intro/tutorial02/>`_ for more information. 

**Install and setup the apps**

1. One of the most important points for using ``ttaa_base`` is that is you need two extra files in your mysite/mysite project folder: ``mysite_configs.py`` allows to set some settings for your app. ``context_processors.py`` takes those settings, adds some more meta data and allows using that information in the front end. Example files for both are provided `there <http://10.101.92.51/ttaa_framework/ttaa_base/tree/dev/examples>`_. Remember to always change ``mysite`` to the actual name of your project. 

2. Modify ``mysite\mysite\__init__.py`` like so:

    .. code-block:: python

        from django.utils.version import get_version

        VERSION = (0, 0, 0, 'alpha', 1)
        __version__ = get_version(VERSION)

  You have to adapt ``VERSION`` to whatever your project team decides on for versioning. Using ``(0, 0, 0, 'alpha', 1)``
  is typically a good choice for the first version of your project, but it has to be discussed and defined project-specific.
        
3. Install ``ttaa_base`` in your django project by modifying ``mysite\setting.py``.


.. Note::
   In order to use custom models for the logger, read the documentation of the function ``get_loggers()`` in :ref:`06_source:Config`.

.. Note::
   Do not just copy and paste everything, try to understand what you are actually doing.

These are mostly configurations:

    .. code-block:: python

        ...
        # Override message name to match bootstraps
        from django.contrib.messages import constants as messages
        
        # loging options
        import logging.config
        from ttaa_base.logger.config import get_loggers

        ...

        LOGGING_CONFIG = None  # Deactivate default logging
        logging.config.dictConfig(get_loggers())

        ...

        INSTALLED_APPS = [
            ...
            'test_app', #Substitute with the name of your django app
            'ttaa_base', 
            ...
        ]

        MIDDLEWARE = [
            ...
            # Installs the ttaa_base middlewares, comment if don't want to use
            'ttaa_base.middleware.session.SessionExpirationMiddleware',
            'ttaa_base.middleware.password_change.PasswordChangeMiddleware',
            'ttaa_base.middleware.admin_tool_lock.AdminToolLock',
        ]

        LOGIN_URL = '/base/auth/login/' # Sets the correct login URL used by ttaa_base

        TEMPLATES = [
            {
               ...
                'DIRS': [ 
                    'test_app/templates/', #Let's the django project know about where your templates reside
                    'ttaa_base/templates/'
                ],
                ...
                    'context_processors': [
                        ...
                        'mysite.context_processors.app_info_menu' # Installs the context processor
                        ...
                    ],
                },
            },
        ]
        ...

        AUTH_PASSWORD_VALIDATORS = [
            {
                'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
            },
            {
                'NAME': 'ttaa_base.validation.password.TTAAPasswordValidator',
            },
            {
                'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
            },
            {
                'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
            },
        ]
        ...


        # #############################################################
        # #Do not modify beyond this line unless you know what you do #
        # #############################################################
       
        # Django-> bootstrap messages types: overrides the normal tags of django
        # messages to be compatible with bootstrap
        MESSAGE_TAGS = {
            messages.ERROR: 'danger'
        }     
        
        # cookies
        SESSION_EXPIRE_AT_BROWSER_CLOSE = True

        # SSL protection
        # Https auto redirection: in debug mode it will not redirect, but in no
        # debug mode it will redirect. There is no ssl certificate in debug mode
        SECURE_SSL_REDIRECT = not DEBUG

        # Cross-Frame Scripting Protection
        X_FRAME_OPTIONS = 'DENY'

        # use secure cookies and CSRF
        SESSION_COOKIE_SECURE = not DEBUG
        CSRF_COOKIE_SECURE = not DEBUG
        
4. Now you need to setup some empty views - the procedure more or less follows the official django tutorial. In the following, we will create the two views ``home`` and ``about`` and assign them their url routes. ``ttaa_base`` needs at least these two views, but you should of course adapt them to your needs. Create ``test_app\urls.py`` like so:

    .. code-block:: python
    
        from django.conf.urls import url

        from . import views

        urlpatterns = [
            url(r'home/', views.home, name='home'),
            url(r'about/', views.about, name='about'),  
        ]

5. Create ``test_app\views.py`` like so:

    .. code-block:: python
    
        from django.contrib.auth.decorators import login_required
        from django.http import HttpRequest
        from django.shortcuts import render

        @login_required
        def home(request):
            """
            Renders the home page.
            
            :param request: HttpRequest: Standard httprequest from Django
            :return: rendering of the page    
            """  
            assert isinstance(request, HttpRequest)

            return render(
                request,
                'test_app/home.html',
                {'title':'Home Page'}
            )
            
        @login_required
        def about(request):
            """
            Renders the about page.
            
            :param request: HttpRequest: Standard httprequest from Django
            :return: rendering of the page    
            """  
            assert isinstance(request, HttpRequest)

            return render(
                request,
                'test_app/home.html',
                {'title':'About'}
            )    

6. Create ``test_app\templates\test_app\home.html`` like so:

    .. code-block:: html
    
        {% extends "ttaa_base/layout.html" %}

        {% block content %}

        Hello world!

        {% endblock %}

7. Include all urls in ```mysite\urls.py``` like so: 

    .. code-block:: python
    
        from django.conf.urls import url, include
        from django.contrib import admin

        handler404 = 'ttaa_base.views.errors.page_not_found'
        handler403 = 'ttaa_base.views.errors.forbidden'
        handler500 = 'ttaa_base.views.errors.internal_error'

        urlpatterns = [
            url(r'^admin/', admin.site.urls),
            url(r'^test_app/', include('test_app.urls')),
            url(r'^base/', include('ttaa_base.urls'))
        ]

**Start the app**

1. Run ``python manage.py migrate`` to add ttaa_base specific database settings to the project
2. Run ``python manage.py createsuperuser`` to create a user
3. Run ``python manage.py runserver``, navgiate to your home page (server adress printed in the terminal + url extension as specified by your url configuration, for example ``127.0.0.1:8000/test_app/home``) and login with your superuser credentials.

Costumization
-------------

mysite_configs.py
^^^^^^^^^^^^^^^^^
Adapt the file ``mysite_configs.py`` to your needs. Check out the :ref:`06_source:Example configuration file` from the examples folder in gitlab <http://10.101.92.51/ttaa_framework/ttaa_base/blob/dev/examples>`_. Customization options are: 

* Application logo, can be either an svg file or an font-awesome class.
* Flag to toggle EY branding
* Sidebar menu (see below)
* Project short name (e.g. GCAT)
* Project long name  (e.g. Global Compensation Automation Tool)
* Favicon
* Team name (or subtitle) that appears under the project short name in the header 

Sidebar Menu
^^^^^^^^^^^^
You have two options to code your menu: Either, write it in html - and `example file <http://10.101.92.51/ttaa_framework/ttaa_base/blob/dev/examples/menu.html>`_ is provided in the repository. Put it in an appropriate location (e.g. ``test_app\templates\test_app\partials\menu.html``) and point ``mysite_configs.HTML_MENU`` to this location. Or, write it in python directly in ``mysite_configs.py``. If you want to write it in python, here's an example for a two- and three level menu. Set ``'permission': None`` if you have no permission management implemented yet.

    .. code-block:: python
    
        ########################################
        # Example for two and three level menu #
        ########################################
         {  # 1st Level
             'label': 'Uploads',
             'call': [],
             'permission': 'uploader.upload_paymentRecords',
             'fontAwesomeIcon': 'fa fa-cloud-upload',
             'subMenu': [
                 {  # 2nd Level
                     'label': 'Demographic Data',
                     'call': ['uploader:uploadDemographic'],
                     'permission': 'uploader.upload_DemographicData',
                     'fontAwesomeIcon': 'fa fa-upload',
                     'subMenu': False
                 },
                 {  # 2nd Level
                     'label': 'Payment Records',
                     'call': [],
                     'permission': 'uploader.upload_paymentRecords',
                     'fontAwesomeIcon': 'fa fa-upload',
                     'subMenu': [
                         {  # 3rd Level
                             'label': 'Payroll',
                             'call': ['uploader:uploadPaymentsRecords'],
                             'permission': 'uploader.upload_paymentRecords',
                             'fontAwesomeIcon': 'fa fa-file-o',
                         },
                         {  # 3rd Level
                             'label': 'Benefits',
                             'call': ['uploader:uploadBenefitsRecords'],
                             'permission': 'uploader.upload_paymentRecords',
                             'fontAwesomeIcon': 'fa fa-file-o',
                         },
                         {  # 3rd Level
                             'label': 'Collection',
                             'call': ['uploader:uploadCollectionRecords'],
                             'permission': 'uploader.upload_paymentRecords',
                             'fontAwesomeIcon': 'fa fa-file-o',
                         },
                     ]
                 },
                 {  # 2nd Level
                     'label': 'Uploaded Files',
                     'call': ['uploader:fileManager'],
                     'permission': 'uploader.upload_filemanager',
                     'fontAwesomeIcon': 'fa fa-files-o',
                     'subMenu': False
                 },
             ]
         }


Custom CSS and JS
^^^^^^^^^^^^^^^^^
If you want to include CSS and JavaScript in your views, overwrite the extraCSS and scripts django blocks, Here's an example html file:

    .. code-block:: html
    
        {% extends "ttaa_base/layout.html" %}
        {% load static %}

        {% block extraCSS %}

            <!-- Your CSS goes here -->
            <link rel="stylesheet" href="{% static 'test_app/css/custom.css' %}" />

        {% endblock %}

        {% block content %} 

            <!-- Page Content -->
            <!-- Your HTML goes here -->
                
        {% endblock %}

        {% block scripts %}

           <script src="{% static 'test_app/js/custom.js' %}"></script>
           <script type="text/javascript">
               //Your code here
           </script>

        {% endblock %}

Features
--------

Logger
^^^^^^

ttaa_base brings its own system log. This is necessary for several reasons:

* InfoSec requires that we log certain events (like login, logout, failed login attempts etc.) 
* Our applications need to provide an `Audit Trail <https://en.wikipedia.org/wiki/Audit_trail>`_ (Who has done what and when?)
* We may want some internal log and statics on usage or other things to improve our apps.

ttaa_base extends `pythons logging module <https://docs.python.org/3.6/howto/logging.html>`_. However, instead of logging information to the console or a file, ttaa_base logs into the database. The database table is called ``ttaa_base_systemlog`` and defined in :ref:`06_source:Models`. There you can also see all the different fields that are logged. For the experts: We have implemented our own logging handler and configuration file including formatter, feel free to checkout the source code of :ref:`06_source:Logging`. This is the former ttaa_django_logger module which is now merged into ttaa_base.

After setting up your project, have a look at the database to get a feeling for what is going on there. Besides some general fields like timestamps or levels or modules that are filled automatically, you will see five fields: 

=========   =====================================================================
User ID     User ID of the current user as an number, not a foreign key, optional
User IP     User IP adress of the current user as a string, optional
Action      Free text field
Target      Database model name as a string, optional
Target ID   Database model id as a number, not a foreign key, optional
=========   =====================================================================

.. Note::
    We do not use foreign keys because in the event of a foreign key being deleted, also the corresponding log event will be deleted and we do not want that. 

This is a generic structure that you can use to log your own events. In your project, you may have many events that need to be included in the audit trail and that need to be logged. Now, how do you generate a new log entry? Well, the same way you would log anything else in django as described in `Django's logging documentation <https://docs.djangoproject.com/en/1.11/topics/logging/>`_. Say, an admin is currently logged in and you want to log the event

    *Admin (User-ID 1) changed the password of user Herbert (User-ID 2)*

Then, in your apps, you first need to include the following code to load the module

.. code-block:: python

    import logging
    # use the definition of LOGGING_CONFIG for 'db'
    db_logger = logging.getLogger('db')

And to log something, just do:

.. code-block:: python

    extra_context = {
        'user_id': request.user.id,
        'user_ip': request.META.get('REMOTE_ADDR'),
        'target': 'User'
        'target_id': 2
    }
    
    # log something
    # db_logger.<level>('my log message', extra={})
    db_logger.info("Changed password", extra = extra_context) 

For convenience, you can also use the ``log_context`` function to extract the user and target-related information automatically. Note that the optional target argument is a model instance: See :ref:`06_source:Log` for the full documentation:

.. code-block:: python

    user = User.objects.get(id=2)
    db_logger.info("Changed password", extra = log_context(request, target=user)) 


.. Note::
    For a list of 'level' read: https://docs.djangoproject.com/en/1.11/topics/logging/

Both code pieces would create a log entry of the following form: 

=========   ==================
Level       "Info"
User ID     1
User IP     "127.0.0.1"
Action      "Changed password"
Target      "User"
Target ID   2
=========   ==================

Now, you only need to define in your project team which events to log. This is project specific, because "Who has done what and when?" is very project specific. 

.. Note:: If you find that you need to define more fields because you have very specific project requirements, you need to implement your own log handler, formatter, config etc. Feel free to use our code as inspiration.

Admin Panel
^^^^^^^^^^^
ttaa_base brings its own admin panel, reachable via the url your-server.com/admin. It is a customization of Django's panel admin panel. Here, you can

* add and remove user and change their properties and permissions
* do the same for groups.
* do the same for any other models you wish to be manageble by this panel 

If you have more database models you want to be manageble for your project, you can add them to the admin panel by following `django's official documentation <https://docs.djangoproject.com/en/1.11/ref/contrib/admin/>`_. What has changed from Django's default admin panel is that

* the django_admin_log in your database is more comprehensive and includes information not only on which fields have changed, but also which are the old and new values
* you cannot modify important dates (e.g tamper with last login dates)
* you cannot create superusers

All of these changes are InfoSec requirements. If you further need to customize the admin panel for user and group management, feel free to extend our TTAAUserAdmin and TTAAGroupAdmin classes. You can use the source code of :ref:`06_source:Admin` for inspiration how to do that. For customization options, see django's official documentation mentioned above. For more details, see the source code documentation of :ref:`06_source:Admin`.

Structure
---------

Classes
^^^^^^^
The following diagram depicts all classes that are defined by ttaa_base. Arrows indicate inheritance. Most classes are not connected because their functionality is included at the project-level via the settings.py file. Not shown are Django-specific and database-related classes. See section :ref:`06_source:Source` for detailed descriptions of each class's functionality. 

.. image:: _static/ttaa_base_classes.png
   :width: 600pt

Database
^^^^^^^^
The following diagram shows the database model structure of ttaa_base as defined in section :ref:`06_source:Models`. 
As some ttaa_base models reference other django models, the django models for the apps 
django.contrib.admin, django.contrib.auth, django.contrib.contenttypes and django.contrib.sessions are also shown. 
A detailed description of the tables and fields is provided in the source code documentation of :ref:`06_source:Models`.

.. image:: _static/db_diagram.png
   :width: 600pt

Python Packages
^^^^^^^^^^^^^^^
The following diagram shows the packages (i.e. files) of ttaa_base and their connections. Arrows indicate imports. Packages that are not connected to any other package typically contain functionality that needs to be introduced project-specific via the settings.py file, or they provide optional functionality. Not shown are Django-specific files (e.g. apps.py or migrations files) and database-related files. 


.. image:: _static/ttaa_base_packages.png
   :width: 600pt

Files and Folders
^^^^^^^^^^^^^^^^^
The following tree shows the files and folders of ttaa_base. Not shown are python specific files (like ``__init__.py``) and the vendor-specific static files. The structure is based on django functionality and not on features. For example, the folders ``middleware`` and ``signals`` both host a file called ``admin_tool_lock.py`` which includes functionality regarding the tool-lock-on-admin-login-feature. However, the former handles the part of the feature related to `Django Middleware <https://docs.djangoproject.com/en/1.11/topics/http/middleware/>`_ functionality while the latter handles the part related to `Django Signals <https://docs.djangoproject.com/en/1.11/topics/signals/>`_ functionality. Also, ``helpers`` subfolders contain functionality that is only used by the respective parent functionality folder while one "global" helpers folder contains functionality shared by all packages. The structure of :ref:`06_source:Source` resembles this tree.

::

    |   admin.py
    |   apps.py
    |   conf.py
    |   constants.py
    |   models.py
    |   urls.py
    |   
    +---helpers
    |   |   access_strings.py
    |   |   account.py
    |   \---log.py
    |           
    +---logger
    |   |   config.py
    |   \---handlers.py
    |           
    +---middleware
    |   |   admin_tool_lock.py
    |   |   password_change.py
    |   |   session.py
    |   |   
    |   +---helpers
    |       \---admin_tool_lock.py
    |           
    +---migrations
    |   \---0001_initial.py
    |           
    +---signals
    |   |   admin_tool_lock.py
    |   \---logging.py
    |           
    +---static
    |   \---ttaa_base
    |       +---css
    |       +---images
    |       +---js
    |       \---vendor
    |           +---bootstrap
    |           +---DataTables
    |           +---django-contrib-admin
    |           +---font-awesome
    |           +---font-notosans
    |           +---html5shiv
    |           +---jquery
    |           +---js-cookie
    |           +---respond
    |           \---sb-admin
    |                       
    +---templates
    |   +---account
    |   |       password_change_done.html
    |   |       password_change_form.html
    |   |       profile.html
    |   |       
    |   \---ttaa_base
    |       |   app_locked.html
    |       |   layout.html
    |       |   logged_out.html
    |       |   login.html
    |       |   
    |       +---errors
    |       |       403.html
    |       |       404.html
    |       |       500.html
    |       |       
    |       \---partials
    |               dynamic_menu.html
    |               favicon.html
    |               footer.html
    |               loginpartial.html
    |               message.html
    |               navigation_side.html
    |               navigation_top.html
    |               
    +---templatetags
    |   \---ttaa_base.py
    |           
    +---validation
    |   |   password.py
    |   |   
    |   \---helpers
    |       \---password.py
    |           
    \---views
        |   account.py
        \---errors.py       


==========================
Frequently Asked Questions
==========================

**I have a dynamic menu written in python. My sublevels do not show when I click on a first level menu item with submenu. Why?**

Maybe you have given a call argument for the upper level item? If so, then when you try to open the subemnu, the page given in 'call' will be requested and rendered, and the submenus will be collapsed again. Thus, the menu item that opens the respective menu cannot have a call argument. See `here <http://10.101.92.214:8000/ttaa_base/03_usage.html#sidebar-menu>`_ for an example and see how some of the calls are blank? That's always in those menu items that have a submenu.

**How can I change the background/background color/sidemenu colors/menu width or remove the sidebar or visually costumize the template?**

The purpose of the TTAA framework is to make all TTAA web apps appear and work the same. If you do what you intent to do, you defeat that purpose. We, the developers, do not encourage defeating the purpose of our framework. Having said that, the framework is flexible enough to support those costumizations. So, if you want still want to defeat our purpose - and you should have a damn good reason to do so - you can create a custom css file, include it in your html files as shown `here <http://10.101.92.214:8000/ttaa_base/03_usage.html#custom-css-and-js>`_ and feel guilty. For example, here's custom css code to add a background image and hide the side navigation bar: 

.. code-block:: css

    /* Add a background image  */
    #page-wrapper{
       background-image: url('/url/to/the/image');        
       background-size: cover;    
       margin-left: 0px;  
    }

    /* hide the side navigation bar  */
    .sidebar{
      display: none;
    }

    /* hide the button for side nav bar*/
    .sidebar-toggler{
       visibility: hidden; 
    }


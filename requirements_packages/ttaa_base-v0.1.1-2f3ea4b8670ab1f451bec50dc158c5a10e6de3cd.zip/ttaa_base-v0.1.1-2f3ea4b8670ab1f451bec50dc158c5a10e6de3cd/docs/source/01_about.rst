=====
About
=====

Description
-----------

Basic package from the EY - TTAA team in Stuttgart used to provide middleware, template and functionalities just out of the box.
It is based on `SB-Admin 2.0 <https://startbootstrap.com/template-overviews/sb-admin-2/>`_. Among its functionalities is the configuration for password strength, expiring sessions, configuring secure cookies, etc. 

**Code**: http://10.101.92.51/ttaa_framework/ttaa_base

*Why should I use this package?* 

In short, you should use it because it will simplify your life. This package is mandatory to be InfoSec and TTAA compliant. Here are some things that come with ttaa_base that you don't have to worry about anymore: 

* A functional, configurable and responsive front end template, EY branded
* Up-to-date js and css libraries like Bootstrap, jQuery, and many more
* Functionality to ensure that all passwords are InfoSec approved
* Functionality to lock the tool when an Admin makes changes
* A logger who automatically logs user activity that's not project-specific and that can be extended to log everything else that is project specific
* An InfoSec-approved admin panel

*How can I contribute* 

Contributions are very welcome. See our `issue tracker <http://10.101.92.51/ttaa_framework/ttaa_base/issues/>`_ for known issues and send us a merge request with a fix if you like. If you want to become a member of the core team, contact the authors.

Middleware
^^^^^^^^^^

There are three middleware included in the package, both of them required to be activated

* ``PasswordChangeMiddleware``: used to force the user to change their passwords after some time
   * Admins 45 days
   * normal users 60 days
* ``AdminToolLock``: Used to lock the app when an admin logs in.
* ``SessionExpirationMiddleware``: Used to expire the session of a user after a certain time of inactivity

Views
^^^^^

Some default views are also provided:

* ``profile``: basic user profile, it shows the permissions and some quick links to the user.
* ``password_change``: password change view.
* ``login``: default view for login interface.

It also provides one of the default themes used by the different apps intended to be EY compliant.

Logging
^^^^^^^
* If the system is correctly configured, it will save the following information:

  * Log in
  * Log out
  * Failed attempt to login

Password strength
^^^^^^^^^^^^^^^^^
* For users changing their password by using the web interface, the following requirements are ensured:

  * Cant be used in less than 24 times in a row
  * Length:
    - 10 for normal users
    - 15 for administrators (is_staff) 

  * It should contain:
      - At least one uppercase letter
      - At least one lowercase letter
      - At least one digit

  * Can't be a common password
  * Can't be entirely numeric


Built With
^^^^^^^^^^

The following libraries are included:

* `Bootstrap 3.3.7 <http://getbootstrap.com/getting-started/>`_
* `Datatables 1.10.15 with Responsive 2.1.1 <https://datatables.net/>`_
* `Font Awesome 4.7.0 <http://fontawesome.io/>`_
* `Font Noto Sans <https://fonts.google.com/specimen/Noto+Sans/>`_
* `HTML5Shiv 3.7.3 <https://github.com/aFarkas/html5shiv>`_
* `jQuery 3.2.1 <http://api.jquery.com/>`_
* `JavaScript Cookie 2.1.4 <https://github.com/js-cookie/js-cookie>`_
* `Respond 1.4.2 <https://github.com/scottjehl/Respond>`_


Requirements
------------

* `Python 3.6 <https://www.python.org/>`_
* `Django 1.11.5 <https://www.djangoproject.com/>`_
* `ttaa_utils <http://10.101.92.51/ttaa_framework/ttaa_utils>`_

Please also note requirements.txt. 

Note: ttaa_utils is listed in requirements.txt. However, if you want to install the package using ``pip install -r requirements.txt``, it will not (yet) work. This is because the ttaa_* packages are not included in open python repositories, which is where pip will look for the requirements. Therefore, you have to install the ttaa_* packages manually before running ``pip install -r requirements.txt``. Instructions are provided with each package.
Still, for the sake of completeness and consistency, the ttaa_* packages are (and should be) listed in the requirements.txt.


Meta Information
----------------

:Authors:
    Stefan Otte, 
    Cristian González Mora

:Version: 0.1.1 of 2017/11/09

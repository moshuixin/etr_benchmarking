=============
Release Notes
=============

0.1.1
-----

Welcome to TTAA Base 0.1.1 release, which is now at the master branch in the Gitlab repository at http://10.101.92.51/ttaa_framework/ttaa_base/tree/master 

*Features/Bug Fixes:*

* Closed #36: Team name/subtitle and favicon are now customizable via mysite_configs.py
* Closed #41: Session expiration for users after 30 mins of inactivity (InfoSec requirement)
* Function within_last_x() in validation.helpers.password corrected so that now check of previously checked passwords now works as intended (InfoSec requirement)
* New file conf.py which will host default values and constants 

*Problem reports and getting help:*

If you have a problem, please check in our `issue tracker <http://10.101.92.51/ttaa_framework/ttaa_base/issues/>`_ if there is already a bug report and contribute to that if necessary. Else, open up a new issue. Even better, after doing so, fix the bug and send us a merge request. 


0.1.0
-----

Welcome to TTAA Base 0.1.0 release.

*Features:*

* A functional, configurable and responsive front end template, EY branded
* Common css and js libraries
* Functionality to ensure that all passwords are InfoSec approved
* Functionality to lock the tool when an Admin makes changes
* A logger who automatically logs user activity that's not project-specific and that can be extended to log everything else that is project specific
* An InfoSec-approved admin panel
* InfoSec-approved session duration

*Suitability and Stability:* 

This release is intended to provide a stable reference point for developers wanting to work on production-level applications that use ttaa_base. However, it’s not the 1.0 release, and we may be introducing further changes before 1.0. Changes that are already sheduled for a further release: 

* Static vendor folder contains django-contrib-admin, which will be removed in a future release

*Problem reports and getting help:*

If you have a problem, please check in our `issue tracker <http://10.101.92.51/ttaa_framework/ttaa_base/issues/>`_ if there is already a bug report and contribute to that if necessary. Else, open up a new issue. Even better, after doing so, fix the bug and send us a merge request. 



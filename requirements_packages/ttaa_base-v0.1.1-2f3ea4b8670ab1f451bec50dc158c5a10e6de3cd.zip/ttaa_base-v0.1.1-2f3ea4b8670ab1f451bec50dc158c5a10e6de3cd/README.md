The documentation can be found at

    http://10.101.92.214:8000/ttaa_base/

* Username: Florian
* PW: TTAA!2017

In case the documentation server is down, please install the requirements and build the documentation by executing

    make html
    
in the docs/ folder, then open 

    docs/build/html/index.html

to access the documentation. 

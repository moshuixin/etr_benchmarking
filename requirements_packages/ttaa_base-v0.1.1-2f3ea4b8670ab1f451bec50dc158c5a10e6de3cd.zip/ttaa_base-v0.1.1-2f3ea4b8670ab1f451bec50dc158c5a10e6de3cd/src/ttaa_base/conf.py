"""
This file should be used to define all the default values for any
configuration.
"""
import django.conf


# The class AppSettings was copied entirely from django-countries
class AppSettings(object):
    """
    A holder for app-specific default settings that allows overriding via
    the project's settings.
    """

    def __getattribute__(self, attr):
        if attr == attr.upper():
            try:
                return getattr(django.conf.settings, attr)
            except AttributeError:
                pass
        return super(AppSettings, self).__getattribute__(attr)


class Settings(AppSettings):
    """Wrapper for all the default values used by the tool"""

    SESSION_INACTIVITY_LOGOUT = 30*60  # in seconds
    """ The duration in seconds that a session might stay inactive."""


settings = Settings()

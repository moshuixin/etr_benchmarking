"""
# ttaa_base

## Description
Basic package from the EY - TTAA team in Stuttgart used to provide basic middleware, template and funcionalities just out of the box.
## Package

### Middleware
There are two middleware included in the pakage:

* PasswordChangeMiddleware : used to force the user to change their passwords
* AdminToolLock: Used to lock the app when an admin logs in.
* SessionExpirationMiddleware: Used to expire the session of a user after a certain time of inactivity

### Views
Some default views are also provided:
* profile: basic user profile, it shows the permissions and some quick liks to the user.
* password_change: password change view.
* login: default view for login interface.

It also provides one of the default themes used by the different apps intended co be EY compliant.

### Requirements
* Python 3.6
* Django 1.11
* ttaa_utils
For further requirements please read: requirements.txt
"""

default_app_config = 'ttaa_base.apps.TtaaBaseConfig'

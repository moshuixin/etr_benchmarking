from django.contrib.auth.hashers import check_password
from ttaa_base.models import Password_Change_Log
from ttaa_base import constants


def within_last_x(user, password_new_clean, password_old_hashed,
                  limit=constants.LAST_CHANGES):
    """
    Checks if the user is using a password within the last 'limit' attempts.

    :param user: django user: user to check
    :param password_new_clean: str: clean version of the password.
    :param password_old_hashed:  str: hashed version of the old password
    :param limit: int: number of times to check for old passwords

    :return: bool: True if the password has being used before (within
      last limit-times), False if not.

    """
    changes = Password_Change_Log.objects.filter(user=user).order_by('-id')[:limit]

    # first change (no logs)
    if not len(changes):
        # make a record with the old password, using the join date as value
        pass_entry = Password_Change_Log(user=user,
                                         password=password_old_hashed)
        pass_entry.save()
        # since the timestamp is given automatically, force the update
        pass_entry.timestamp = user.date_joined
        pass_entry.save(update_fields=['timestamp'])

        result = check_password(password_new_clean, password_old_hashed)
        # if new does not match old, make a log with new
        if not result:
            pass_entry2 = Password_Change_Log(user=user,
                                              password=user.password)
            pass_entry2.save()
        return result

    # iterate over the last logs
    for change in changes:
        # if any matches, escape
        if check_password(password_new_clean, change.password):
            return True
    # if no one matches, store it and return that it was not used
    pass_entry = Password_Change_Log(user=user,
                                     password=user.password)
    pass_entry.save()
    return False

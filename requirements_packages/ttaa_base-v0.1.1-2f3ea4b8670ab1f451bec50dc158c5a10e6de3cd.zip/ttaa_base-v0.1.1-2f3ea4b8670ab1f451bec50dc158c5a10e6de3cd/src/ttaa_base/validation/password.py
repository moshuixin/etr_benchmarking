import string

from django.core.exceptions import ValidationError
from django.db.models import Max
from django.utils import timezone
from django.utils.translation import ungettext
from ttaa_base.models import Password_Change_Log
from ttaa_base import constants


class TTAAPasswordValidator(object):
    """
    Validate whether the password satisfies the minimal requirements for EY
    IT teams in terms of strength: length and presence of defined type of
    characters.
    """
    def __init__(self, min_length=10, min_length_admin=15, min_uppercase=1,
                 min_lowercase=1, min_digits=1):
        self.min_length = min_length
        self.min_length_admin = min_length_admin
        self.min_uppercase = min_uppercase
        self.min_lowercase = min_lowercase
        self.min_digits = min_digits

    def validate(self, password, user=None):
        """Validates the length of the password as well as the presence of
        defined types of characters: digits, lowercase and uppercase. If the
        any of the requirements is not satisfied an exception raises. Since an
        error is raised, returns are not required.

        :param password: str: password to validate
        :param user: user to validate the password for

        :return: None

        """
        if user and user.is_staff:
            self.min_length = self.min_length_admin

        self.validate_digits(password)
        self.validate_uppercase(password)
        self.validate_lowercase(password)

        if len(password) < self.min_length:
            raise ValidationError(
                ungettext(
                    "This password is too short. It must contain at least %(min_length)d character.",
                    "This password is too short. It must contain at least %(min_length)d characters.",
                    self.min_length
                ),
                code='password_too_short',
                params={'min_length': self.min_length},
            )

    def validate_digits(self, password):
        """
        Validates the amount of digits present in the password. If the
        required amount not satisfied, rises an exception. Since an
        error is raised, returns are not required.

        :param password: str: password to validate
        :return: None

        """

        digits = sum(c.isdigit() for c in password)
        if digits < self.min_digits:
            raise ValidationError(
                ungettext(
                    "This password must contain %(min_digits)d digit.",
                    "This password must contain %(min_digits)d digits.",
                    self.min_digits
                ),
                code='password_digits',
                params={'min_digits': self.min_digits},
            )

    def validate_uppercase(self, password):
        """
        Validates the amount of uppercase letters present in the password.
        If the required amount not satisfied, rises an exception. Since an
        error is raised, returns are not required.

        :param password: str: password to validate
        :return: None

        """

        uppercase = len(set(string.ascii_uppercase).intersection(password))
        if uppercase < self.min_digits:
            raise ValidationError(
                ungettext(
                    "This password must contain %(min_uppercase)d capital letter.",
                    "This password must contain %(min_uppercase)d capital letters.",
                    self.min_uppercase
                ),
                code='password_digits',
                params={'min_uppercase': self.min_uppercase},
            )

    def validate_lowercase(self, password):
        """
        Validates the amount of lowercase letters present in the password.
        If the required amount not satisfied, rises an exception. Since an
        error is raised, returns are not required.

        :param password: str: password to validate
        :return: None

        """

        min_lowercase = len(set(string.ascii_lowercase).intersection(password))
        if min_lowercase < self.min_lowercase:
            raise ValidationError(
                ungettext(
                    "This password must contain %(min_lowercase)d lowercase letter.",
                    "This password must contain %(min_lowercase)d lowercase letters.",
                    self.min_lowercase
                ),
                code='password_digits',
                params={'min_lowercase': self.min_lowercase},
            )

    def get_help_text(self):
        """ Help test to show to the user

        :return: str
        """
        requirements = "Your password must contain at least: {min_length}  " \
                       "character(s), {min_uppercase} uppercase letter(s), " \
                       "{min_lowercase} lowercase letter(s) and " \
                       "{min_digits} digit(s). ".format(
                           min_length=self.min_length,
                           min_uppercase=self.min_uppercase,
                           min_lowercase=self.min_lowercase,
                           min_digits=self.min_digits)
        return requirements


def password_validity(user):
    """
    Calculates the amount of days a password still is valid.

    :param user: user to calculate the validity from.

    :return: int: amount of remaining days a password id valid

    """
    # password change information:
    delay = constants.USER_PASS_SPAN  # default users

    if user.is_staff:  # staff/admins
        delay = constants.ADMIN_PASS_SPAN

    # default last pass update, join date of the user
    date_joined = user.date_joined

    # last change log
    last_change = Password_Change_Log.objects.filter(user=user).aggregate(
        date_max=Max('timestamp'))['date_max']

    # if there is record of last password change, use it
    if last_change:
        last_date = last_change
    # or take the join date as default
    else:
        last_date = date_joined

    difference = (timezone.now()-last_date).days
    return max(0, delay-difference)

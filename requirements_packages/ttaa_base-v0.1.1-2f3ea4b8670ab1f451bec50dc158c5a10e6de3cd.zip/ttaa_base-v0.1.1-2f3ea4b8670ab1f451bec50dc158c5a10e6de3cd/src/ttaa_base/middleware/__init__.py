"""
Collection of middleware intended for Infosec compliance.
At the moment it contains just two:
  * password_change.PasswordChangeMiddleware: enforces the user to change
  her/his password after a certain amount of days.
  * tool.AdminToolLock: when a user with elevated rights (staff, admin) logs
  in, the tool is blocked for all other users. This block is for all,
  even other admins. Elevated right means that the user has the flag
  is_staff as True in Django.

They are divided in different files in function of what category they belong
to.
"""
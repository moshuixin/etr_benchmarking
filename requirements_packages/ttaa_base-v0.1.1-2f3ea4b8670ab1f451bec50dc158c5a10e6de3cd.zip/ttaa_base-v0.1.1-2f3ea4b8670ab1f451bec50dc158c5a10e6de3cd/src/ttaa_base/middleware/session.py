from django.utils.deprecation import MiddlewareMixin
from ttaa_base.conf import settings


class SessionExpirationMiddleware(MiddlewareMixin):
    """Middleware intended to update the duration of the session of the
    current user to the maximum duration defined in the tool. The idea is to
    make sure the user will get logged out automatically after a defined
    periode of inactivity. Default: 30*60 s.
    """

    def process_request(self, request):
        """Takes the current request of an logged in user to have a defined
        maximal duration in function of the defaults set in settings.py or
        the default defined in ttaa_base

        :param request: HttpRequest: Standard httprequest from Django
        :return: None/HttpResponseRedirect: None

        """
        if not hasattr(request, 'user') or not request.user.is_authenticated:
            return None

        request.session.set_expiry(settings.SESSION_INACTIVITY_LOGOUT)
        return None

"""
Helper functions for the AdminToolLock Middleware
"""

from datetime import timedelta
from django.utils import timezone

from ttaa_base.models import Admin_Login
from ttaa_base import constants


def is_app_locked(last_lock):
    """
    Checks if the app is locked. This is true if either an admin is
    currently logged and if the last activity of the admin does not
    exceed a certain timespan.

    :param last_lock: Admin_Login: Instance of Admin_Login object
    :return: bool: True if the app is locked, False if not.

    """

    if not last_lock:
        return False

    delta_minutes = constants.OLD_LOCK_TIMESPAN
    starting = last_lock.timestamp

    # check if the lock is old enough
    until = starting + timedelta(seconds=60 * delta_minutes)
    record_is_old = until < timezone.now()

    # if the record is old enough not locked
    if record_is_old:
        return False

    # any other case: is locked by somebody
    return True


def get_last_app_lock():
    """
    Returns the last Admin_Login object from the database. Needed in
    several places where the current lock status of the tool has to
    be checked.

    :return: Admin_Login: Most recently created Admin_Login object

    """

    last_lock = Admin_Login.objects.filter(
        status=constants.Statuses.ACTIVE.key).order_by('-id').first()
    return last_lock


def update_lock(lock):
    """
    Updates the timestamp of the lock object to the current time
    and stores it into the database.

    :param lock: Admin_Login: Instance of Admin_Login object where the
        timestamp is to be updated
    :return: None

    """

    if not lock:
        return
    lock.timestamp = timezone.now()
    lock.save(update_fields=['timestamp'])


def lock_app(user):
    """
    Locks the app.

    :param user: user: user who sets the lock
    :return: None

    """
    lock = Admin_Login(user=user)
    lock.save()


def unlock_app(user):
    """
    Releases lock of the tool by the given user

    :param user: user who releases the lock
    :return: None

    """
    admin_log = Admin_Login.objects.filter(user=user,
                                           status=constants.Statuses.ACTIVE.key)
    admin_log.update(status=constants.Statuses.INACTIVE.key)

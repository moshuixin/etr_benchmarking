"""
This module contain JUST small functions (helpers) used by the middlewares.
These where before located in helpers. However, since they are (and were)
intended for Middleware, they are now here.
"""
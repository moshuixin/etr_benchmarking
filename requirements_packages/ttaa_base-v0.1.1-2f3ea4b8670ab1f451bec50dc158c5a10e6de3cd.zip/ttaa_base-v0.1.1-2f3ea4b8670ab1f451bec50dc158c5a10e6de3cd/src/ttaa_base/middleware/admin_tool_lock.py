from django.http.response import HttpResponseRedirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from ttaa_base.middleware.helpers import admin_tool_lock


class AdminToolLock(MiddlewareMixin):
    """Middleware intended to lock the application every time an admin logs in.
    It is considered admin a user that has 'is_staff' as boolean True. By
    default the user will be sent to a view that says that the app is locked
    and he/she can not perform any action.
    A white list that allows users to view pages related to those names.
    """

    # places where the user is free to stay without checking for the middleware
    # this redirection depend in the routes defined in urls, do not change!
    WHITE_LIST = ["locked/", "password_change/", "auth/logout/", "profile/",
                  "about/"]

    response_redirect_class = HttpResponseRedirect

    def process_request(self, request):
        """Checks if the application is locked by an admin loged in

        :param request: HttpRequest: Standard httprequest from Django
        :return: None/HttpResponseRedirect: None if no action must be taken,
            HttpResponseRedirect if redirect action to 'password_change' if
            password mut be changed
        """
        if not request.user.is_authenticated:
            return None

        # whitelist for non locked routes
        for page in self.WHITE_LIST:
            if page in request.path:
                return None

        last_lock = admin_tool_lock.get_last_app_lock()
        # to reduce number of queries
        locked = admin_tool_lock.is_app_locked(last_lock)

        if not locked:
            if request.user.is_staff:
                # if no lock and user is admin, lock the app
                admin_tool_lock.lock_app(request.user)
            return None

        # Reach this point only if app is locked
        if request.user.id == last_lock.user.id:
            admin_tool_lock.update_lock(last_lock)
            return None

        return self.response_redirect_class(reverse('app_locked'))

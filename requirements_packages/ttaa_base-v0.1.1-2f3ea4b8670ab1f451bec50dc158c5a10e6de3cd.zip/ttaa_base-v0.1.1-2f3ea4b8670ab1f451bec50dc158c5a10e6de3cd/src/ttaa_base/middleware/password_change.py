from django.http.response import HttpResponseRedirect
from django.utils.deprecation import MiddlewareMixin
from django.urls import reverse
from ttaa_base.validation.password import password_validity


class PasswordChangeMiddleware(MiddlewareMixin):
    """Middleware intended to force the user to change her/his password if
    it older than the allowed maximum.
    If any other page is visited besides the logout and the profile
    functions, the user will be redirected to the password change view.
    """
    response_redirect_class = HttpResponseRedirect

    # places where the user is free to stay without checking for the middleware
    # this redirection depend in the routes defined in urls, do not change!
    WHITE_LIST = ["password_change/", "auth/logout/", "profile/", "about/"]

    def process_request(self, request):
        """Checks if the user has to change its password or not

        :param request: HttpRequest: Standard httprequest from Django
        :return: None/HttpResponseRedirect: None if no action must be taken,
            HttpResponseRedirect if redirect action to 'password_change' if
            password mut be changed
        """
        if not request.user.is_authenticated:
            # nothing to check
            return None

        remaining_days = password_validity(request.user)
        if remaining_days > 0:
            return None

        # if user is in any of the white listed pages: can stay
        for page in self.WHITE_LIST:
            if page in request.path:
                return None
        # in any other case it gets redirected to password change
        return self.response_redirect_class(reverse('password_change'))

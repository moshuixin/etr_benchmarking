"""
This module overrides Django's User and Group Admin Panels to incorporate
custom security features. More specifically, it prevents admins
from changing information that should not be modifiable (e.g.
last login or date joind of specific users) and extends what is being
logged in the django_admin_log database table.
"""

from collections import Iterable

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.contrib.auth.models import User, Group
from django.forms import Form


class TTAAAdminMixin():
    """
    This mixin (https://en.wikipedia.org/wiki/Mixin) defines functions
    that are shared by other Admin classes.
    """

    def construct_change_message(self, request, form, formsets, add=False):
        """
        Construct a JSON structure describing changes from a changed object.
        This is a modification from the original django function. In addition
        to Django's functionality to log the fields that were changed,
        this function also logges the old and new values of the
        changed fields.

        Note that the old and new values of passwords are empty.
        A password change log exists in the ttaa_base_password_change_log
        table.
        """

        # Initialize required variables
        changed_data = form.changed_data  # Get data from form that has changed
        change_message = []

        if not add and changed_data:
            old_data = []
            new_data = []
            for changed_field in changed_data:
                old_field = form.initial.get(changed_field)
                new_field = form.cleaned_data.get(changed_field)
                # If field data is a list, try to collapse to ID's only
                # The if-condition arises because old_field seems to be
                # returned as a list whereas new_field seems to be
                # returned as a Django Queryset.
                # If collapse doesn't work, original data is stored
                if isinstance(new_field, Iterable):
                    try:
                        old_field = [value.id for value in list(old_field)]
                        new_field = [value.id for value in list(new_field)]
                    except:
                        pass
                old_data.append(old_field)
                new_data.append(new_field)

            change_message.append({'changed': {
                'fields': form.changed_data,
                'old': old_data,
                'new': new_data,
            }})

        # Send an empty form using "Form()" to super so we receive
        # only the parts of the change_message that
        # we do not override (i.e. the ones corresponding to the formset
        # and the add flag)
        change_message.extend(
            super(TTAAAdminMixin, self).construct_change_message(
                request, Form(), formsets, add
                )
        )
        return change_message


class TTAAGroupAdmin(TTAAAdminMixin, GroupAdmin):
    """
    Customization of the Group Admin Panel. Extends Django's
    GroupAdmin class by including the TTAAAdminMixin.
    """
    pass


class TTAAUserAdmin(TTAAAdminMixin, UserAdmin):
    """
    Customization of the User Admin Panel. Extends Django's
    UserAdmin class by including the TTAAAdminMixin and redefining
    some other security-related properties.
    """

    def __init__(self, *args, **kwargs):
        super(TTAAUserAdmin, self).__init__(*args, **kwargs)
        self.readonly_fields = ('is_superuser', 'last_login', 'date_joined')
        """
        Definition of fields which are visible, but not editable to
        the admin who is logged in.
        """


# Here, we remove Django's UserAdmin from the Admin panel
# and add our own custom User panel
admin.site.unregister(User)
admin.site.register(User, TTAAUserAdmin)
admin.site.unregister(Group)
admin.site.register(Group, TTAAGroupAdmin)

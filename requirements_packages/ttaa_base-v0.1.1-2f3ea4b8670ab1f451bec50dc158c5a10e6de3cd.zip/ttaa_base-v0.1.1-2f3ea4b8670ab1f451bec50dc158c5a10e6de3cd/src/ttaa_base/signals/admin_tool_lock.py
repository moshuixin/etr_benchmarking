"""Callbacks used by AdminToolLock Middleware"""
from django.contrib.auth.signals import user_logged_out
from django.dispatch import receiver
from ttaa_base.middleware.helpers import admin_tool_lock


@receiver(user_logged_out)
def logout_callback(sender, request, **kwargs):
    """
    Callback for after a user logs out. This call unlocks the app
    when the user that is being logged out is an admin.

    :param sender: signal sender (login module)
    :param request: HttpRequest: Standard http request from Django
    :param kwargs: key arguments
    :return: None

    """
    if request.user.is_staff:
        # Make log of the user logging in in order to lock the tool
        admin_tool_lock.unlock_app(request.user)

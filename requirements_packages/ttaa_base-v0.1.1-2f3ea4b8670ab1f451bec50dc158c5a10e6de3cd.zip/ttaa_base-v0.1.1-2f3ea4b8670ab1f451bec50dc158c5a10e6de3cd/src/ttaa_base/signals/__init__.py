"""
This package contains the methods that are called when a signal is
triggered, such as when an user logs in, logs out, etc.
They are divided in different files in function of what category they belong
to.
"""
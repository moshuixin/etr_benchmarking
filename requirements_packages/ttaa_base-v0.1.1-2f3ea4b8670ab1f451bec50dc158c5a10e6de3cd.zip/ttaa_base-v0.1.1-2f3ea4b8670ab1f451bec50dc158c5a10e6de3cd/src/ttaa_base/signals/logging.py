"""
Callbacks used by the package to log the actions of the users by login
related methods
"""

from django.dispatch import receiver
from django.contrib.auth.models import User
from django.contrib.auth.signals import user_logged_in, user_logged_out
from django.contrib.auth.signals import user_login_failed
from ttaa_base.models import Account_Locks
from ttaa_base import constants
from ttaa_base.helpers.log import log_context

import logging
db_logger = logging.getLogger('db')


@receiver(user_logged_in)
def login_callback(sender, request, user, **kwargs):
    """
    Callback for after a user logs in. This call is used to log who is
    loging in.

    :param sender: signal sender: signal sender (login module)
    :param request: HttpRequest: Standard http request from Django
    :param user: logged in user
    :param kwargs:  key arguments
    :return:  None
    """

    # after successful login erase lock count.
    user_locks = Account_Locks.objects.filter(user=user)
    user_locks.delete()
    db_logger.info('login', extra=log_context(request, user))


@receiver(user_logged_out)
def logout_callback(sender, request, user, **kwargs):
    """
    Callback for after a user logs out. This call is used to log who is
    logging out.

    :param sender: signal sender: signal sender (login module)
    :param request: HttpRequest: Standard http request from Django
    :param user: logged in user
    :param kwargs:  key arguments

    :return:  None

    """

    if not request.user.is_authenticated:
        return

    db_logger.info('logout', extra=log_context(request, user))


@receiver(user_login_failed)
def login_failed_callback(sender, credentials, request, **kwargs):
    """
    Callback for after a failed login attempt. This call is used
    to log who has tried to login but failed.

    :param sender: signal sender: signal sender (login module)
    :param credentials: dictionary: dictionary containing credentials used.
    :param request: HttpRequest: Standard http request from Django
    :param kwargs:  key arguments

    :return: None

    """

    limit = constants.LOGIN_ATTEMPTS_BEFORE_LOCK
    username = credentials['username']

    # By failing the login register the attempts of the user if it exists
    # if the user exists
    exists = False
    log_message = 'Login failed'
    user = None  # assume there is no user

    try:
        user = User.objects.get(username=username)
        exists = True
    except Exception as e:
        log_message += ' username=[{username}] '.format(username=username)

    db_logger.info(log_message, extra=log_context(request, user))

    # if user does not exists, there is nothing to do
    if not exists:
        return
    # Just existing users reach this point. Add 1 to the failed log attempts
    to_update, created = Account_Locks.objects.get_or_create(user=user,
                                                             attempts__lt=limit
                                                             )
    if not created:
        to_update.attempts += 1
    to_update.save()
    attempts = to_update.attempts

    if to_update.attempts == limit:
        log_message += 'Account lock, attempts=[{attempts}]'.format(
            attempts=attempts)
        db_logger.info(log_message, extra=log_context(request, user))

"""dataMapper URL Configuration.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""

from django.conf.urls import url
from django.contrib import auth
from django.contrib.auth.views import logout

from ttaa_base.views import account

# Assign custom view and context to authentication system

# Some urls are used in middleware, do not change unless you match the
# corresponding middleware
urlpatterns = [
    url(r'^locked/', account.app_locked, name='app_locked'),

    # Assign custom view and context to authentication system
    url(r'^auth/logout/',
        logout,
        {
            'template_name': 'ttaa_base/logged_out.html',
            'next_page': '/'
        },
        name='logout'),
    url(r'^auth/login/$', account.login, name='login'),
    url(r'profile/', account.profile, name='user_profile'),
    url(r'password_change/$', account.password_change, name='password_change'),

    url(r'password_change/done/$', auth.views.password_change_done,
        {
            'template_name': 'account/password_change_done.html',
            'extra_context': {'title': 'Password changed'}
        },
        name='password_change_done'),
]

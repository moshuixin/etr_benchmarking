"""
Definition of custom tags to be used with the templates.
"""
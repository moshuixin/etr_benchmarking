# -*- coding: utf-8 -*-
"""Custom template tags for ttaa_base"""

from collections import Iterable
from django import template

register = template.Library()


@register.simple_tag
def has_perm(user, permissions):
    """
    Since there is no way to address the permissions dynamically in the
    and sorts them in a list. Then, it checks if the asked permission in that
    tempalte for a list of permissions or even for a single one this tag
    provides the functionality.

    :param permissions: str/iterable: string of iterable
      containing django permission strings of the form <app>.<permission>.

    :return: bool: True if the user has at least one of the given
      permissions. False if not.

    """
    if permissions is None:
        return True
    # if a string is pass, use the normal method
    elif isinstance(permissions, str):
        return user.has_perm(permissions)

    # if an iterable is pass, check assume that the elements are permission
    # strings and return True if the user has at leas one of them
    elif isinstance(permissions, Iterable):
        for permission in permissions:
            if user.has_perm(permission):
                return True
    return False


@register.filter
def divide(value, arg):
    """
    Template tag to divide two values. This is useful in cases where
    you need to transform percentages to values between 0 and 1 or
    where you have a currency in cents and need to display it
    as euros/dollars/... Example usage in the html file:

    .. code-block:: html

        {{ value_in_cents|divide:100 }}

    where value_in_cents is a numeric value from the backend.

    :param value: Nominator of the division
    :param arg: Denominator of the division
    :return: result of the division
    """

    try:
        return int(value) / int(arg)
    except (ValueError, ZeroDivisionError):
        return None

"""
This file contains the definitions of the database models used by TTAA Base.
All the models involve a kind of logging and related information associated
to them.

..Note:
  The pep8 naming convention regarding classes is not used in this file due
  to a very simple reason: Model names are used to create table names by
  using them in their lower case form. This means that for declaring tables
  with a meaningful name in the database, we use underscores here.

"""

from django.contrib.auth import get_user_model
from django.db import models
from ttaa_base import constants

User = get_user_model()


class User_Event(models.Model):
    """
    Provides an user and timestamp for the events that need to be logged for
    the different users. Timestamps are automatically created and should stay
    like that since they are set server side.
    """
    user = models.ForeignKey(User)
    """Foreign key to user model"""
    timestamp = models.DateTimeField(auto_now_add=True)
    """
    Timestamp is automatically added at the time of database entry creation
    """

    class Meta:
        abstract = True
        default_permissions = ()
        app_label = 'ttaa_base'


class Admin_Login(User_Event):
    """
    Model intended to store information about when an admin logged in
    and used to lock the app if necessary. The timestamp is used to check
    for duration of the lock, which should be in principle, the same
    duration than the sessions of the users.
    """
    status = models.SmallIntegerField(choices=constants.Statuses.tuples(),
                                      default=constants.Statuses.ACTIVE.key)
    """Status whether the admin login is active or not"""

    class Meta:
        default_permissions = ()
        app_label = 'ttaa_base'


class Password_Change_Log(User_Event):
    """
    Model intended to store the successful password change events of each user.
    It keeps the hashed version that will be afterwards use to check new
    passwords against.
    """
    password = models.CharField('password', max_length=128)
    """Hashed password"""

    class Meta:
        default_permissions = ()
        app_label = 'ttaa_base'


class Account_Locks(User_Event):
    """
    Model intended to store the failed login attempts from the
    different users in order to lock the accounts and stop them
    from logging in.
    """
    attempts = models.SmallIntegerField(default=1)
    """Number of times the respective user has logged in."""

    class Meta:
        default_permissions = ()
        app_label = 'ttaa_base'


class Base_System_Log(models.Model):
    """
    Abstract class used to serve as base to define custom logs. In order
    to be able to have a table in the db to write on, this model must be
    extended by each application that uses this app.
    There are no foreign keys used since the deletion of one of them will
    delete the records here too.
    """
    level = models.CharField(max_length=200)
    """Log level according to the django log level hirarchy"""
    method = models.CharField(max_length=200)
    """Python method that has written the log"""
    file_path = models.TextField()
    """File path in which the python method resides"""
    user_id = models.PositiveSmallIntegerField(null=True,
                                               blank=True,
                                               default=None)
    """User ID from the used that has caused the log entry"""
    user_ip = models.CharField(max_length=15, default="")
    """IP adress from the used that has caused the log entry"""
    action = models.TextField(default="")
    """Action that was performed by the user"""
    target = models.CharField(max_length=200, default="")
    """Database model name on which the action was performed"""
    target_id = models.IntegerField(null=True, blank=True, default=None)
    """Database entry id on which the action was performed"""
    timestamp = models.DateTimeField(auto_now_add=True)
    """
    Timestamp is automatically added at the time of database entry creation
    """
    module = models.CharField(max_length=300)
    """
    Logging module that has caused the log entry. This distinguishes
    between django-internal log entries and other custom log entries
    """

    class Meta:
        default_permissions = ()
        abstract = True
        app_label = 'ttaa_base'


class System_Log(Base_System_Log):
    """
    Implementation of the Base_System_Log model, it extends Base_System_Log.
    It currently does not additonal fields but sets meta information of
    the table that appears in the database.
    """

    class Meta:
        verbose_name = 'System log'
        default_permissions = ()
        app_label = 'ttaa_base'

"""
Definition of constants and enumerations used by the tool. It centralizes
definitions in order to not to hardcode them anywhere.
"""

from ttaa_utils.constants import LabeledEnum

LAST_CHANGES = 24
"""Number of changes after what a password can be used again"""

ADMIN_PASS_SPAN = 45
"""Span in days an admin has to change his passwords"""

USER_PASS_SPAN = 60
"""Span in days a regular user has to change his passwords"""

OLD_LOCK_TIMESPAN = 30
"""
Span in minutes of inactivity after which an admin session expires
and the tool gets unlocked
"""

LOGIN_ATTEMPTS_BEFORE_LOCK = 5
"""Defines after how many login attempts the accounts gets locked"""

SPAN_ACCOUNT_LOCK_MINUTES = 30
"""
Span in minutes the accounts becomes
locked after too many login attemps
"""


class Statuses(LabeledEnum):
    """General purpose statuses enumeration"""

    INACTIVE = (0, 'Inactive')
    ACTIVE = (1, 'Active')

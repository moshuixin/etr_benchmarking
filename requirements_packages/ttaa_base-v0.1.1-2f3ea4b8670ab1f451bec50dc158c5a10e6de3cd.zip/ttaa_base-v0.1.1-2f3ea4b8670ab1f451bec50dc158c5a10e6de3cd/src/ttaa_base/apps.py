"""
This consist of the some general configurations for the application. Using
this, one can configure some of the attributes of the application. An
example of them is  the inclusion of the triggers and the definition of the
app name.
"""
from django.apps import AppConfig


class TtaaBaseConfig(AppConfig):
    name = 'ttaa_base'

    def ready(self):
        # Signals used by middleware
        from ttaa_base.signals import admin_tool_lock, logging

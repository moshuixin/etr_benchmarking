"""
Definitions of views for the default errors handlers: 403, 404 and 500
"""

from django.shortcuts import render
from django.http import HttpRequest
from django.contrib.auth.decorators import login_required


@login_required(login_url='login')
def forbidden(request):
    """
    Alternative view for the error 403 (forbidden) visualisation.

    :param request: HttpRequest: Standard httprequest from Django
    :return: rendering of the error view

    """
    assert isinstance(request, HttpRequest)
    context = {
        'title': 'Forbidden',
    }
    response = render(request, 'ttaa_base/errors/403.html', context)
    response.status_code = 403
    return response


def page_not_found(request):
    """
    Alternative view for the error 404 visualisation.

    :param request: HttpRequest: Standard httprequest from Django
    :return: rendering of page not found

    """
    assert isinstance(request, HttpRequest)
    context = {
        'title': 'Error 404',
    }
    response = render(request, 'ttaa_base/errors/404.html', context)
    response.status_code = 404
    return response


def internal_error(request):
    """
    Alternative view for the error 500 visualisation.

    :param request: HttpRequest: Standard httprequest from Django
    :return: rendering of the error view

    """
    assert isinstance(request, HttpRequest)
    context = {
        'title': 'Error 500',
    }
    response = render(request, 'ttaa_base/errors/500.html', context)
    response.status_code = 500
    return response

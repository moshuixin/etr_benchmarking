"""
Views for user account management 
"""

import logging

from django.contrib import messages
from django.contrib.auth import login as auth_login, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm, AuthenticationForm
from django.contrib.auth.models import Group
from django.contrib.auth.views import deprecate_current_app
from django.http import HttpRequest
from django.shortcuts import render, redirect
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from ttaa_base.middleware.helpers.admin_tool_lock import is_app_locked, \
    get_last_app_lock
from ttaa_base.helpers.account import group_permissions_sort
from ttaa_base.helpers.account import is_user_locked
from ttaa_base.helpers.log import log_context
from ttaa_base.validation.password import password_validity
from ttaa_base.validation.helpers.password import within_last_x

db_logger = logging.getLogger('db')


def app_locked(request):
    """
    Renders a dummy page useful to assign and test calls during development.

    :param request: HttpRequest: Standard httprequest from Django

    :return: rendering of the users profile

    """

    assert isinstance(request, HttpRequest)
    if not is_app_locked(get_last_app_lock()):
        return redirect('home')

    return render(request, 'ttaa_base/app_locked.html', {})


@login_required(login_url='login')
def profile(request):
    """
    Renders the users profile page with information concerning the account
    and user permissions. It also bring some quick links for account
    administration:

    * change password

    :param request: HttpRequest: Standard httprequest from Django
    :return: rendering of the users profile

    """
    assert isinstance(request, HttpRequest)

    user = request.user
    permissions = group_permissions_sort(user)
    groups = Group.objects.filter(user=user)
    grups_names = []
    for g in groups:
        grups_names.append(str(g.name))

    remaining_days = password_validity(user)
    if remaining_days < 1:
        messages.error(request, "Your password is expired. please change it "
                                "now.")
    elif remaining_days < 11:
        messages.warning(request, "Your password expires in [{}] days. "
                                  "Please consider to change it son."
                                  "".format(remaining_days))

    context = {
        'title': 'Profile',
        'permissions': permissions,
        'userGroups': grups_names,
        'remaining_days': remaining_days
    }
    return render(request, 'account/profile.html', context)


@sensitive_post_parameters()
@csrf_protect
@login_required(login_url='login')
@deprecate_current_app
@never_cache
def password_change(request, password_change_form=PasswordChangeForm):
    """
    Custom view for the password change view, it cares about filtering the
    use of old passwords by calling 'within_last_x()'

    :param request: HttpRequest: Standard http request from Django
    :param password_change_form: user-based form: form used to change the user
      password
    :return: rendering of the page

    """
    title = 'Password change'

    # user making the action
    user = request.user

    if not password_validity(user):
        messages.error(request,
                       "Your password is expired. please change it "
                       "now.")

    if request.method == "POST":
        form = password_change_form(user=request.user, data=request.POST)
        # take the user pass before the change
        password_old_hashed = user.password
        if form.is_valid():
            user = form.save(commit=False)  # update user, without saving
            password_new_clean = form.cleaned_data.get('new_password1')
            # new password to save
            within = within_last_x(user, password_new_clean,
                                   password_old_hashed)
            # if it does not pass the count of changes, do not change!
            if within:
                messages.warning(request, "Previously used password, "
                                          "cant use again.")
                return render(request, 'account/password_change_form.html',
                              {'form': form})
            user.save()

            db_logger.info("Password changed", extra=log_context(request, user))
            # Updating the password logs out all other sessions for the user
            # except the current one.
            update_session_auth_hash(request, user)
            return redirect('user_profile')
    else:
        form = password_change_form(user=user)

    for field in ['old_password', 'new_password1', 'new_password2']:
        form.fields[field].widget.attrs.update({
            'autocomplete': 'off'
        })

    context = {
        'form': form,
        'title': title,
    }
    return render(request, 'account/password_change_form.html', context)


@deprecate_current_app
@sensitive_post_parameters()
@csrf_protect
@never_cache
def login(request):
    """
    Displays the login form and handles the login action. It also checks
    for the maximum number of attempts the user can use.

    :param request: HttpRequest: Standard http request from Django
    :return: rendering of the page

    """
    if request.user.is_authenticated:
        return redirect('home')

    form = AuthenticationForm()
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)

        if form.is_valid():
            user = form.get_user()
            if is_user_locked(user):
                messages.error(request, "Your account is locked.")
                return redirect('login')

            auth_login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Invalid credentials.")

    for field in ['username', 'password']:
        form.fields[field].widget.attrs.update({
            'autocomplete': 'off'
        })

    context = {
        'form': form,
    }
    return render(request, 'ttaa_base/login.html', context)

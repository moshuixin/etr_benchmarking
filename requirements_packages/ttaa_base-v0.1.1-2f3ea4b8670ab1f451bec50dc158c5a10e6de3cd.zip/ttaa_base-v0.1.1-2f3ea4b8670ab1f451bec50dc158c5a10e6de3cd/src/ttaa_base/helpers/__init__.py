"""
Collection of methods commonly used by forms, views and middleware.
"""

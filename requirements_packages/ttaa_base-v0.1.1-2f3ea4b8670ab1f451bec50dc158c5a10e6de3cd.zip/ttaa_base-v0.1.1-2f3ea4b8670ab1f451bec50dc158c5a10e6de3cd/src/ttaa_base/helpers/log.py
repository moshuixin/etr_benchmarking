"""
Collection of functions used to make the logging process easier for the user.
"""

from django.db import models


def log_context(request, target=None, extra_context={}, processor=False):
    """ Shortcut to generate log information related to user activity
    triggered by a request.

    :param request: HttpRequest: Standard http request from Django
    :param target: Model instance: instance of a model, it will be
        used to extract the model (db table) affected by the log and
        extract its id.
    :param extra_context: original dictionary to fill the information in
    :param processor: function: extra function to process data passed with
        extra_context. This will be performed as last step.

    :return: dict: dictionary with updated values extracted from the request
        and target

    """

    if request:
        extra_context['user_ip'] = request.META.get('REMOTE_ADDR')

        user = request.user
        if user.is_authenticated:
            extra_context['user_id'] = user.id

    if 'target' not in extra_context.keys() and isinstance(target, models.Model):
        extra_context['target'] = target.__class__.__name__
        try:
            extra_context['target_id'] = target.id
        except:
            pass

    if processor:
        extra_context = processor(extra_context)

    return extra_context

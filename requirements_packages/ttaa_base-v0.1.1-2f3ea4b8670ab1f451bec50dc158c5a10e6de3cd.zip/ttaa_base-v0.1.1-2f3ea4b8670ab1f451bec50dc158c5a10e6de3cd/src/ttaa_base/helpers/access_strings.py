"""
Provides methods to generate strings related to access of different kind.
such as permissions and routes (defined in urls).
This methods are useful, for example, if you define your permissions or
routenames with any king of constant definition.

For namespace information, please refer to
https://docs.djangoproject.com/en/1.11/topics/http/urls/

"""


def permission_string(app_name, permission):
    """ Generates a string conformed by an application name and a particular
    permission in the form: <app>.<permission> if an app name is given or
    <permission> if not. It does not bring anything to use it just with
    permission, but nobody knows why anyone would do that.

    :param app_name: str : name of the application to get the permission of
    :param permission: str : string containing a django permission
    :return: str: string

    >>> permission_string('my_app', 'permission')
    'my_app.permission'

    """
    if not app_name:
        return permission
    return app_name + '.' + permission


def callback_string(app_name, route_name):
    """
    Generates the callback string to be used application wide in the form
    <app>:<route_name>, if an app_name is given, otherwise just the
    route_name <route_name>.

    This string represents the namespaces defined in urls.

    :param app_name: str : (namespace) name of the application to get the
       callback to
    :param route_name: str: target route_name withing this app
    :return: call str : call string

    >>> callback_string('my_app', 'route_name')
    'my_app:route_name'

    """
    if not app_name:
        return route_name
    return app_name + ':' + route_name

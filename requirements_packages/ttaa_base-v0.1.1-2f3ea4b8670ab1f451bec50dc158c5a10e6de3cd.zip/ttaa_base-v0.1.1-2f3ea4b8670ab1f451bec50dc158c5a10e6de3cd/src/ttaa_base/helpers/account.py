"""
Collection of methods intended to be used in account related processes.
Within the provided methods there is one to check ifr is locked due to
failed login attempts and assignation of permissions to groups and users.
"""
from collections import OrderedDict, defaultdict
from datetime import timedelta

from django.contrib.auth.models import Permission, Group
from django.contrib.auth import get_user_model
from django.db import transaction
from django.utils import timezone

from ttaa_base import constants
from ttaa_base.models import Account_Locks

User = get_user_model()


def is_user_locked(user,
                   attempts_limit=constants.LOGIN_ATTEMPTS_BEFORE_LOCK,
                   delta_minutes=constants.SPAN_ACCOUNT_LOCK_MINUTES):
    """ Check if the user has prohibition to log in due to many failed attempts

    :param user: django user: user to check
    :param attempts_limit: int: number of attempts that block the account
    :param delta_minutes: float/int: number of minutes of the user to keep
      locked.
    :return: bool: True if the user is locked, False if not.

    """

    # From the locks select the one that belong to that user
    locks = Account_Locks.objects.filter(user=user)

    # no record of locks, user is free
    if not locks:
        return False

    starting = locks[0].timestamp
    attempts = locks[0].attempts

    # validity of the lock
    until = starting + timedelta(seconds=60 * delta_minutes)
    record_is_old = until < timezone.now()

    # if the record is old enough: user free
    # or if the attempts are less than the limit: user free
    if record_is_old or attempts < attempts_limit:
        # intentionally return the attempts as 0
        return False

    # any other case, user locked
    return True


def group_permissions_sort(user):
    """
    Returns a dictionary where the keys are the different models and the
    values are formed by the permissions (in human friendly format) that the
    user can access.

    :param user: user instance
    :return:  OrderedDict: dictionary of permissions organized by module

    """
    perm_dict = defaultdict(list)
    u_permissions = list(Permission.objects.filter(user=user))
    g_permissions = list(Permission.objects.filter(group__user=user))

    for p in u_permissions + g_permissions:
        type_ = str(p.content_type).title()  # capitalize first letter
        if p.name not in perm_dict[type_]:
            perm_dict[type_].append(p.name)
    sorted_perms = OrderedDict(sorted(perm_dict.items()))

    return sorted_perms


@transaction.atomic
def add_user_permissions(permissions_list, users):
    """
    Intended to be used with default users permissions.
    :param permissions_list: list: list of strings with the permissions\
        codes the target user will receive
    :param users: list: list of usernames that will receive the permissions

    :return: bool: True if assignment was successful, False if not
    """
    permissions = Permission.objects.filter(codename__in=permissions_list)
    try:
        for username in users:
            target_user = User.objects.get(username=username)
            target_user.user_permissions.add(*permissions)
    except Exception as e:
        print(e)
        return False
    return True


@transaction.atomic
def add_groups_permissions(groups_permissions):
    """ Assign a list of permissions to the given groups

    :param groups_permissions: dict: dictionary where the keys are the \
      groups names and the values are the permissions strings that the group \
      receive.
    :return: bool: True if assignment was successfull, False if not
    """

    try:
        for group_name in groups_permissions.keys():
            group = groups_permissions[group_name]
            permissions = group['permissions']
            inherit = group['inherit']

            if inherit and inherit in groups_permissions.keys():
                inherit_group = groups_permissions[inherit]
                permissions += inherit_group['permissions']

            target_group = Group.objects.get(name=group_name)
            grants = Permission.objects.filter(codename__in=permissions)
            if grants:
                target_group.permissions.add(*grants)
                target_group.save()
    except Exception as e:
        print(e)
        return False
    return True

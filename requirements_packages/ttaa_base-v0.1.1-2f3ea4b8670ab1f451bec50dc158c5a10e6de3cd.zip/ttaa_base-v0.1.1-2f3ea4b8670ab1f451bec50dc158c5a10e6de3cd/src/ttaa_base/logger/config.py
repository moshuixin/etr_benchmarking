"""
This files defines the logging configuration (i.e. handlers,
formatters, filters and loggers) for the ttaa_base system log.
"""


def get_loggers(app='ttaa_base',
                class_package='logger.handlers.TtaaBaseHandler'):
    """
    Base configuration for the Django tool that will use the log.

    :param app: str: name of the app what will use the log. This
      configuration along the 'class_package' define which model will be used
      to store the data.
    :param class_package: str: format: '<module>.<handler>' specifies the
      module and handler tha will store the logs. The handler can be use other
      models besides the provided by ttaa_base.

    :return: dict: dictionary containing the logging configuration.

    """
    # Own logging settings
    LOGGING = {
        'version': 1,
        'disable_existing_loggers': True,
        'formatters': {
            'standard': {
                'format': '%(levelname)s %(asctime)s %(name)s %(funcName)s: %(message)s'
            },
        },
        'handlers': {
            'database': {
                'level': 'INFO',
                'class': app + '.' + class_package,
                'formatter': 'standard'
            },
        },
        'loggers': {
            'db': {
                'handlers': ['database'],
                'level': 'INFO',
                'propagate': False,
            },
            'django': {
                'handlers': ['database'],
                'level': 'INFO',
            },
        }
    }
    return LOGGING

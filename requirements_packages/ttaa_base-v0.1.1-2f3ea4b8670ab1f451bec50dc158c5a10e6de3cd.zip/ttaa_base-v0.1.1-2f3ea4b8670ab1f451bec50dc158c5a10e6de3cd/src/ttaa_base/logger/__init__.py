"""
Collection of all classes and methods needed to get the logging 
functionality up and running.
"""

""" Definitions of handler for the logs """
from logging import Handler


class TtaaBaseHandler(Handler):
    """
    It implements the methods to save record in the DB or to a fallback file if
    the DB could not be used. In the last case the file has the name of the
    class that tries to save the log into the DB + '.txt'.
    This class has to be extended by other django applications in order to
    define the correct table to log the information to (if required).
    """

    errors = {
        'model_not_found': 'Model not found. Impossible to write log.',
        'not_writable': 'Log not writable. Impossible to write log.'
    }
    model = None
    backup_file = ''

    def __init__(self):

        super(TtaaBaseHandler, self).__init__()
        # run the regular Handler __init__
        Handler.__init__(self)
        self.backup_file = str(self.__class__.__name__) + '.log'

    def _file_fall_back(self, record, **kwargs):
        """
        In case a log could not be writen. It tries to
        save into a text file with the name of the class as name.

        :return: None

        """

        # Format string as specified by formatter
        str_ = self.format(record)

        try:
            outfile = open(self.backup_file, "a")
            outfile.write(str_ + "\n")
            outfile.close()
        except Exception as e:
            print(e)
            print(self.errors['not_writable'])
            print("Fallback Collapse:", str_)

    def _get_model(self):
        """
        Loads the implemented System_Log model to write the log to.

        :return: Django Model or None: use
        """
        # NOTE: need to import this here otherwise it causes a circular
        # Reference and doesn't work i.e. settings imports loggers
        # imports models imports settings...

        if self.model:
            return self.model
        try:
            from ttaa_base.models import System_Log
            self.model = System_Log
            return self.model
        except Exception as e:
            print(self.errors['model_not_found'])

        return None

    def emit(self, record, save=True):
        """Method intended to save into the DB.

        :param record: log record
        :param save: bool: if True, it saves directly to the DB.
        :return: django model / None model use to write into the DB. see
          '_get_model()'.

        """

        if not record:
            return

        # Make dictionary from record items
        dic = record.__dict__

        # instantiate the model
        model = self._get_model()

        if not model:
            print(self.errors['model_not_found'])
            return None
        try:
            log_entry = model(
                level=record.levelname,
                method=record.funcName,
                user_id=dic.get('user_id'),
                user_ip=dic.get('user_ip', ""),
                action=record.getMessage(),
                target=dic.get('target', ""),
                target_id=dic.get('target_id'),
                module=record.name,
                file_path=record.pathname)
            if save:
                log_entry.save()
            return log_entry
        except Exception as e:
            print(e)
            self._file_fall_back(record)
            print("Impossible to save log", self.__class__.__name__)
        return None
